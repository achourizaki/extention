# OCR Capture & Form Filler

Browser extension (Chrome, Edge, Brave, Firefox) that reads text from screenshots, **classifies every value automatically**
(name, first name, birth date, phone, ID number, offer…) and **fills PDF or Word forms**, ready to print.
Everything runs locally: no Internet needed, no data leaves the computer.

## Features
- **Collect:** draw a box around one value or a whole customer card (Alt+S), or analyse the visible page.
  Tesseract OCR (WebAssembly) + rule-based classifier (`src/classify.js`).
- **Fill:** upload any PDF or Word form; fields are detected automatically (`src/detect.js`, `src/docfill.js`,
  `src/scan.js` for scanned pages) and filled with `pdf-lib`. Fields can be adjusted in the built-in editor.
- **Packages:** one source, five builds: `chrome` (MV3), `chrome-ancien` (MV2, Chrome 74+), `edge`, `edge-ancien`, `firefox` (MV2, Firefox 62+).

## Project layout
| Path | Content |
|---|---|
| `src/` | extension source shared by all builds (popup, background, content script, OCR, classifier, detector, form filler) |
| `src/preset/` | Mobilis migration form with its ready-made field map |
| `build.js` | builds the packages into `dist/` (transpiles for old browsers, bundles libs and OCR data) |
| `test/agent/` | test agent: generates fake profiles, draws screenshots, runs OCR + classification + PDF filling, reports accuracy |
| `test/e2e/` | real-browser tests (Playwright + Chromium, network blocked) |
| `test/fixtures/` | sample forms and a page with fake customer cards |
| `tools/promo/` | animated promo video generator (HTML + Playwright + ffmpeg) |

## Build
```bash
npm install
npm run build          # -> dist/ocr-capture-chrome, -chrome-ancien, -edge, -edge-ancien, -firefox
npm run build:zip      # -> dist/packages/*.zip and the Firefox .xpi
```

## Load in a browser
- **Chrome / Edge:** `chrome://extensions` (or `edge://extensions`) > Developer mode > *Load unpacked* > pick a folder from `dist/`.
- **Firefox:** `about:debugging#/runtime/this-firefox` > *Load Temporary Add-on* > pick `manifest.json` of `dist/ocr-capture-firefox`.

## Tests
```bash
npm run test:agent                      # OCR + classification + PDF accuracy on generated profiles
pip install playwright && playwright install chromium
npm run test:e2e                        # collect + fill in a real Chromium, offline
npm run test:e2e-forms                  # import brand-new PDF / Word / scanned forms
npm run lint:firefox                    # Mozilla web-ext lint
```
Set `CHROME_BIN` to use another Chromium binary. Test data is fake; never commit real customer data.

## Known limits
- Scanned (image-only) forms are only partly recognised; finish them in *Edit fields*.
- OCR language: French/English (Arabic not read yet).
- Firefox and very old browser versions were not verified on real browsers (Chromium 141 only).
