// Builds 3 packages from /home/claude/src:  chrome (MV3), chrome-ancien (MV2), firefox (MV2)
const fs = require("fs"), path = require("path"), cp = require("child_process");
const esbuild = require("esbuild");
const ROOT = __dirname, NM = path.join(ROOT, "node_modules"), SRC = path.join(ROOT, "src"), DIST = path.join(ROOT, "dist");
const VERSION = "2.0";
const NAME = "OCR Capture & Form Filler";
const DESC = "Lit le texte des captures (noms, dates, téléphones…), le classe automatiquement et remplit vos formulaires PDF/Word. 100 % hors ligne.";
const CMD = { "start-select": { suggested_key: { default: "Alt+S" }, description: "Select an area to read" } };

const APP_JS = ["classify.js", "fill.js", "ocr-config.js", "ocr.js", "detect.js", "scan.js", "docfill.js", "background.js", "content.js", "popup.js", "forms.js", "offscreen.js"];
const APP_OTHER = ["popup.html", "forms.html"];
const LIBS = {   // name -> source path (pdf.js differs per target)
  "browser-polyfill.min.js": NM + "/webextension-polyfill/dist/browser-polyfill.min.js",
  "tesseract.min.js": NM + "/tesseract.js/dist/tesseract.min.js", "worker.min.js": NM + "/tesseract.js/dist/worker.min.js",
  "pdf-lib.min.js": NM + "/pdf-lib/dist/pdf-lib.min.js", "pizzip.min.js": NM + "/pizzip/dist/pizzip.min.js", "docxtemplater.js": NM + "/docxtemplater/build/docxtemplater.js",
  "jszip.min.js": NM + "/jszip/dist/jszip.min.js", "docx-preview.min.js": NM + "/docx-preview/dist/docx-preview.min.js"
};
const CORES = ["tesseract-core-lstm.js", "tesseract-core-lstm.wasm", "tesseract-core-lstm.wasm.js", "tesseract-core-simd-lstm.js", "tesseract-core-simd-lstm.wasm", "tesseract-core-simd-lstm.wasm.js"];

const TARGETS = {
  "chrome": {
    folder: "ocr-capture-chrome", modern: true, mv: 3, offscreen: true,
    manifest: () => ({ manifest_version: 3, name: NAME, version: VERSION, description: DESC, minimum_chrome_version: "109",
      permissions: ["activeTab", "scripting", "storage", "offscreen"], host_permissions: ["<all_urls>"],
      background: { service_worker: "background.js" }, action: { default_popup: "popup.html", default_title: "OCR Capture" }, commands: CMD,
      content_security_policy: { extension_pages: "script-src 'self' 'wasm-unsafe-eval'; object-src 'self'" } })
  },
  "chrome-ancien": {
    folder: "ocr-capture-chrome-ancien", modern: false, target: ["chrome74"], mv: 2,
    manifest: () => ({ manifest_version: 2, name: NAME, version: VERSION, description: DESC, minimum_chrome_version: "74",
      permissions: ["activeTab", "storage", "tabs", "<all_urls>"],
      background: { scripts: ["lib/browser-polyfill.min.js", "lib/tesseract.min.js", "classify.js", "ocr-config.js", "ocr.js", "background.js"], persistent: true },
      browser_action: { default_popup: "popup.html", default_title: "OCR Capture" }, commands: CMD,
      content_security_policy: "script-src 'self' 'unsafe-eval'; object-src 'self'" })
  },
  "firefox": {
    folder: "ocr-capture-firefox", modern: false, target: ["firefox62"], mv: 2,
    manifest: () => ({ manifest_version: 2, name: NAME, version: VERSION, description: DESC,
      browser_specific_settings: { gecko: { id: "ocr-capture@local", strict_min_version: "62.0", data_collection_permissions: { required: ["none"] } } },
      permissions: ["activeTab", "storage", "tabs", "<all_urls>"],
      background: { scripts: ["lib/browser-polyfill.min.js", "lib/tesseract.min.js", "classify.js", "ocr-config.js", "ocr.js", "background.js"], persistent: true },
      browser_action: { default_popup: "popup.html", default_title: "OCR Capture", browser_style: false }, commands: CMD,
      content_security_policy: "script-src 'self' 'unsafe-eval' 'wasm-unsafe-eval'; object-src 'self'" })
  }
};
TARGETS.edge = Object.assign({}, TARGETS.chrome, { folder: "ocr-capture-edge" });
TARGETS["edge-ancien"] = Object.assign({}, TARGETS["chrome-ancien"], { folder: "ocr-capture-edge-ancien" });
const copyDir = (a, b) => fs.cpSync(a, b, { recursive: true });
const warnings = {};
function lower(code, target, file) {
  const r = esbuild.transformSync(code, { target, charset: "utf8", logLevel: "silent", legalComments: "none" });
  if (r.warnings.length) warnings[file] = r.warnings.map((w) => w.text).slice(0, 3);
  return r.code;
}
const only = process.argv[2] && process.argv[2] !== "--zip" ? process.argv[2] : null, makeZip = process.argv.includes("--zip");
fs.mkdirSync(DIST, { recursive: true });
for (const [key, T] of Object.entries(TARGETS)) {
  if (only && only !== key) continue;
  const d = path.join(DIST, T.folder); fs.rmSync(d, { recursive: true, force: true }); fs.mkdirSync(d + "/lib", { recursive: true });
  const put = (rel, code) => fs.writeFileSync(path.join(d, rel), code);
  // app code
  for (const f of APP_JS) {
    if (f === "offscreen.js" && !T.offscreen) continue;
    const code = fs.readFileSync(path.join(SRC, f), "utf8");
    put(f, T.modern ? code : lower(code, T.target, f));
  }
  for (const f of APP_OTHER) put(f, fs.readFileSync(path.join(SRC, f), "utf8"));
  if (T.offscreen) put("offscreen.html", fs.readFileSync(path.join(SRC, "offscreen.html"), "utf8"));
  // libs
  for (const [n, p] of Object.entries(LIBS)) { const code = fs.readFileSync(p, "utf8"); put("lib/" + n, T.modern || n === "browser-polyfill.min.js" ? code : lower(code, T.target, "lib/" + n)); }
  for (const c of CORES) { const buf = fs.readFileSync(NM + "/tesseract.js-core/" + c); if (c.endsWith(".js") && !T.modern) put("lib/" + c, lower(buf.toString("utf8"), T.target, "lib/" + c)); else fs.writeFileSync(path.join(d, "lib", c), buf); }
  const pdfDir = T.modern ? NM + "/pdfjs-dist/build" : NM + "/pdfjs-dist/legacy/build";
  fs.copyFileSync(pdfDir + "/pdf.min.js", d + "/lib/pdf.min.js"); fs.copyFileSync(pdfDir + "/pdf.worker.min.js", d + "/lib/pdf.worker.min.js");
  copyDir(NM + "/pdfjs-dist/cmaps", d + "/lib/cmaps"); copyDir(NM + "/pdfjs-dist/standard_fonts", d + "/lib/standard_fonts");
  copyDir(SRC + "/preset", d + "/preset");
  fs.mkdirSync(d + "/lang", { recursive: true }); fs.copyFileSync(NM + "/@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz", d + "/lang/eng.traineddata.gz");
  put("manifest.json", JSON.stringify(T.manifest(), null, 2));
  put("LISEZMOI.txt", fs.readFileSync(path.join(SRC, "README-" + key + ".txt"), "utf8"));
  console.log("built", T.folder);
}
fs.writeFileSync(path.join(DIST, "warnings.json"), JSON.stringify(warnings, null, 1));
console.log("esbuild warnings:", Object.keys(warnings).length ? JSON.stringify(warnings) : "none");

// optional: node build.js --zip  -> dist/packages/*.zip (+ Firefox .xpi), no external zip tool needed
if (makeZip) {
  const JSZip = require("jszip"), out = path.join(DIST, "packages"); fs.mkdirSync(out, { recursive: true });
  const add = (zip, dir, base) => fs.readdirSync(dir, { withFileTypes: true }).forEach((e) => { const p = path.join(dir, e.name); if (e.isDirectory()) add(zip, p, base); else zip.file(path.relative(base, p).split(path.sep).join("/"), fs.readFileSync(p)); });
  (async () => {
    for (const T of Object.values(TARGETS)) {
      if (!fs.existsSync(path.join(DIST, T.folder))) continue;
      const z = new JSZip(); add(z.folder(T.folder), path.join(DIST, T.folder), path.join(DIST, T.folder));
      fs.writeFileSync(path.join(out, T.folder + ".zip"), await z.generateAsync({ type: "nodebuffer", compression: "DEFLATE" }));
      if (T.folder === "ocr-capture-firefox") { const x = new JSZip(); add(x, path.join(DIST, T.folder), path.join(DIST, T.folder)); fs.writeFileSync(path.join(out, T.folder + ".xpi"), await x.generateAsync({ type: "nodebuffer", compression: "DEFLATE" })); }
      console.log("zipped", T.folder);
    }
  })();
}
