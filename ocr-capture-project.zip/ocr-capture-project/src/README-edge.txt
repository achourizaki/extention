OCR CAPTURE - VERSION MICROSOFT EDGE (récente)
Navigateur : Microsoft Edge (Chromium) version 109 ou plus récente.

INSTALLATION
1. Décompressez le dossier.
2. Dans Edge, ouvrez edge://extensions et activez "Mode développeur" (menu de gauche).
3. Cliquez "Charger l'extension décompressée" et choisissez ce dossier.
4. Épinglez l'icône : bouton "Extensions" (puzzle) de la barre d'outils > épingle à côté de OCR Capture.
Raccourci : Alt+S (modifiable dans edge://extensions/shortcuts).
Pages locales (file://) : edge://extensions > Détails > "Autoriser l'accès aux URL de fichier".
Edge plus ancien que la version 109 ? Utilisez le paquet "edge-ancien".

UTILISATION (identique sur toutes les versions)
PARTIE 1 - COLLECTER (classement automatique)
 - Icône de l'extension > "Sélectionner une zone" (ou Alt+S) : dessinez un cadre autour
   d'une valeur seule (une date, un numéro...) ou de toute une fiche. Le texte est lu et
   rangé automatiquement : Civilité, Nom, Prénom, Date de naissance, Lieu de naissance,
   Téléphone, N° de contact, Pièce, N° pièce, Date de délivrance, Délivrée à, Offre, Montant...
 - "Analyser la page" : lit toute la partie visible de la page.
 - Fond orange + "⚠" = catégorie incertaine : vérifiez-la dans la liste déroulante.
PARTIE 2 - REMPLIR UN FORMULAIRE (détection automatique des champs)
 - "+ Upload PDF / Word" : importez N'IMPORTE QUEL formulaire. L'extension repère toute seule
   "Nom : ......", "Prénom : ____", les cases |__|__|, les cases à cocher (Monsieur / Madame, CIN / Passeport,
   offres...) et y place les valeurs collectées. Rien à configurer.
   * PDF avec texte et Word : détection fiable. Word : aucune balise {{...}} nécessaire.
   * PDF scanné (image) : détection partielle ; complétez dans l'onglet "Edit fields".
 - Si un champ est mal placé : onglet "Edit fields" (déplacez / ajoutez des cases), "Save fields".
   "Re-detect fields automatically" relance la détection.
 - Les valeurs collectées se mettent à jour toutes seules pendant que la page est ouverte.
 - Icône > "Remplir un formulaire". Le formulaire Mobilis est déjà inclus.
 - Choisissez-le, vérifiez les valeurs, "Generate PDF", puis "Open & print".
 - "+ Upload PDF / Word" pour ajouter d'autres formulaires (onglet "Edit fields" pour placer les champs).
HORS LIGNE : tout est inclus (lecture du texte, langue, PDF, Word). Aucune donnée ne quitte l'ordinateur.
