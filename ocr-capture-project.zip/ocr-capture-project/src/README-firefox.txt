OCR CAPTURE - VERSION FIREFOX
Navigateur : Firefox 62 ou plus récent (Firefox ESR 78 / 115 conseillé).

INSTALLATION TEMPORAIRE (toutes les éditions de Firefox, à refaire après chaque redémarrage)
1. Décompressez le dossier.
2. Tapez about:debugging#/runtime/this-firefox dans la barre d'adresse.
3. "Charger un module complémentaire temporaire..." > choisissez le fichier manifest.json du dossier.

INSTALLATION PERMANENTE
 - Firefox Developer Edition, Nightly ou ESR : tapez about:config, mettez
   xpinstall.signatures.required = false, puis about:addons > roue dentée >
   "Installer un module depuis un fichier..." > choisissez ocr-capture-firefox.xpi.
 - Firefox standard : Mozilla impose une signature. Déposez le .xpi sur addons.mozilla.org
   (distribution "non listée", gratuit), puis installez le fichier signé obtenu.
Raccourci : Alt+S (modifiable dans about:addons > roue dentée > "Gérer les raccourcis").
Pages locales (file://) : ouvrez-les simplement ; Firefox autorise l'extension.
Note : la CSP autorise 'unsafe-eval' pour que le moteur WebAssembly fonctionne sur les anciens Firefox.

UTILISATION (identique sur toutes les versions)
PARTIE 1 - COLLECTER (classement automatique)
 - Icône de l'extension > "Sélectionner une zone" (ou Alt+S) : dessinez un cadre autour
   d'une valeur seule (une date, un numéro...) ou de toute une fiche. Le texte est lu et
   rangé automatiquement : Civilité, Nom, Prénom, Date de naissance, Lieu de naissance,
   Téléphone, N° de contact, Pièce, N° pièce, Date de délivrance, Délivrée à, Offre, Montant...
 - "Analyser la page" : lit toute la partie visible de la page.
 - Fond orange + "⚠" = catégorie incertaine : vérifiez-la dans la liste déroulante.
PARTIE 2 - REMPLIR UN FORMULAIRE (détection automatique des champs)
 - "+ Upload PDF / Word" : importez N'IMPORTE QUEL formulaire. L'extension repère toute seule
   "Nom : ......", "Prénom : ____", les cases |__|__|, les cases à cocher (Monsieur / Madame, CIN / Passeport,
   offres...) et y place les valeurs collectées. Rien à configurer.
   * PDF avec texte et Word : détection fiable. Word : aucune balise {{...}} nécessaire.
   * PDF scanné (image) : détection partielle ; complétez dans l'onglet "Edit fields".
 - Si un champ est mal placé : onglet "Edit fields" (déplacez / ajoutez des cases), "Save fields".
   "Re-detect fields automatically" relance la détection.
 - Les valeurs collectées se mettent à jour toutes seules pendant que la page est ouverte.
 - Icône > "Remplir un formulaire". Le formulaire Mobilis est déjà inclus.
 - Choisissez-le, vérifiez les valeurs, "Generate PDF", puis "Open & print".
 - "+ Upload PDF / Word" pour ajouter d'autres formulaires (onglet "Edit fields" pour placer les champs).
HORS LIGNE : tout est inclus (lecture du texte, langue, PDF, Word). Aucune donnée ne quitte l'ordinateur.
