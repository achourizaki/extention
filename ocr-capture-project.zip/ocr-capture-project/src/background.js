// Service worker (Chrome MV3) or background page (Chrome legacy / Firefox). Same code everywhere.
if (typeof importScripts === "function") importScripts("lib/browser-polyfill.min.js", "classify.js");

const BA = browser.action || browser.browserAction;
async function getItems() { const { items = [] } = await browser.storage.local.get("items"); return items; }
async function setItems(items) {
  await browser.storage.local.set({ items });
  BA.setBadgeBackgroundColor({ color: "#2563eb" });
  BA.setBadgeText({ text: items.length ? String(items.length) : "" });
}

// inject the content script: MV3 uses scripting, older browsers use tabs.executeScript
async function inject(tabId) {
  const files = ["lib/browser-polyfill.min.js", "content.js"];
  if (typeof chrome !== "undefined" && chrome.scripting && chrome.scripting.executeScript) {
    await chrome.scripting.executeScript({ target: { tabId }, files });
  } else {
    for (const file of files) await browser.tabs.executeScript(tabId, { file });
  }
}
async function start(mode) {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^(https?|file):/.test(tab.url || "")) return;
  await inject(tab.id);
  browser.tabs.sendMessage(tab.id, { type: mode === "page" ? "capture-page" : "start-select" });
}

// OCR: directly in this page when it has a DOM (legacy / Firefox), otherwise in an offscreen document (MV3)
async function ocr(msg) {
  if (self.OCR) return self.OCR.run(msg);
  if (!(await chrome.offscreen.hasDocument())) {
    await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["DOM_PARSER"], justification: "Crop screenshots and run OCR locally" });
  }
  return browser.runtime.sendMessage(Object.assign({ target: "offscreen", type: "ocr" }, msg));
}

async function handleCapture(msg, sender) {
  const tab = sender.tab, toast = (text) => browser.tabs.sendMessage(tab.id, { type: "toast", text });
  const dataUrl = await browser.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  const res = await ocr({ dataUrl, rect: msg.rect, dpr: msg.dpr });
  const items = await getItems();
  const found = OCRClassify.extract((res && res.text) || "", items.map((i) => i.label));
  if (!found.length) { toast("Aucun texte reconnu, réessayez."); return; }
  found.forEach((f) => {
    const i = f.label === "Texte" ? -1 : items.findIndex((x) => x.label === f.label);
    const it = { id: i >= 0 ? items[i].id : Date.now() + Math.random(), label: f.label, text: f.text, uncertain: f.uncertain, page: tab.url, title: tab.title || "" };
    if (i >= 0) items[i] = it; else items.push(it);
  });
  await setItems(items);
  const sum = found.slice(0, 4).map((f) => f.label + ": " + f.text.slice(0, 22)).join(" • ");
  toast("✓ " + sum + (found.length > 4 ? " (+" + (found.length - 4) + ")" : ""));
}

browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target === "offscreen") return;
  if (msg.type === "start") { start(msg.mode); sendResponse({}); }
  else if (msg.type === "captured") { handleCapture(msg, sender); sendResponse({}); }
  return true;
});
browser.commands.onCommand.addListener((c) => { if (c === "start-select") start("select"); });
browser.runtime.onInstalled.addListener(async () => setItems(await getItems()));
