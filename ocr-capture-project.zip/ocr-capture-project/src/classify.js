// Reads OCR text and sorts every value into the right field (name, birth date, phone...).
// Shared by the extension (background.js) and the test agent.
(function (root) {
  const norm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
  const CATS = ["Civilité", "Nom", "Prénom", "Date de naissance", "Lieu de naissance", "Téléphone", "N° de contact", "Pièce", "N° pièce", "Date de délivrance", "Délivrée à", "Offre", "Montant", "Email", "Adresse", "Texte"];
  const LABELS = {
    "Civilité": ["civilite", "titre", "genre", "sexe"],
    "Nom": ["nom", "name", "lastname", "surname", "nomdefamille", "nomfamille"],
    "Prénom": ["prenom", "prenoms", "firstname", "givenname"],
    "Date de naissance": ["datedenaissance", "datenaissance", "naissance", "nele", "nee", "nelee", "birthday", "birthdate", "dateofbirth", "dob"],
    "Lieu de naissance": ["lieudenaissance", "lieunaissance", "birthplace", "placeofbirth"],
    "Téléphone": ["telephone", "tel", "phone", "mobile", "portable", "gsm"],
    "N° de contact": ["ndecontact", "numerodecontact", "contact", "numcontact"],
    "Pièce": ["piece", "typedepiece", "pieceidentite", "typepiece"],
    "N° pièce": ["ndelapiece", "numerodelapiece", "numeropiece", "npiece", "numerodepiece", "idnumber", "ndepiece", "ncin"],
    "Date de délivrance": ["delivreele", "datededelivrance", "datedelivrance", "delivrele", "issuedate", "delivrance"],
    "Délivrée à": ["delivreea", "lieudedelivrance", "lieudelivrance", "issueplace"],
    "Offre": ["offre", "offer", "forfait", "abonnement"],
    "Montant": ["montant", "amount", "prix"],
    "Email": ["email", "mail", "courriel"],
    "Adresse": ["adresse", "address", "domicile"]
  };
  const OFFERS = ["WIN MAX LIBRE", "WIN MAX CONTROL", "TWENTY PREMIUM", "SAMA CONTROL", "SAMA LIBRE", "SAMA", "TWENTY"];
  const AMOUNTS = ["650", "1000", "1300", "1500", "2000", "3500"];
  const FIRST = new Set(("Mohamed Ahmed Yacine Amine Karim Walid Riad Sofiane Abdelkader Youcef Omar Ali Hocine Rachid Nabil Samir Hamza Ilyes Mehdi Bilal Abdelhak Mustapha Said Farid Redouane Zakaria Abdelhamid Nacer Fares Anis Lyes Hakim Toufik Salim Amel Sarah Lamia Nadia Meriem Fatima Imene Samira Khadidja Aicha Asma Hanane Nawel Sabrina Yasmine Lina Rania Soumia Wafa Djamila Houria Karima Leila Malika Nesrine Selma Zineb Ikram Amina Chaima Racha Ines Maissa").split(" ").map(norm));
  const SURN = new Set(("Benali Boudiaf Messaoudi Haddad Cherif Bouzid Khelifi Mansouri Belkacem Saidi Ferhat Lounis Brahimi Boumediene Bensalem Benabdallah Bouchama Merabet Hamdi Kaci Slimani Taleb Yahiaoui Amrani Bouaziz Belaid Guerroudj Meziane Rahmani Ziani Djebbar Hamidi Larbi Mebarki Naceri Ouali Sahraoui Tounsi Zerrouki Boukhalfa Chelghoum").split(" ").map(norm));
  const PLACES = new Set(("Alger Blida Oran Constantine Annaba Batna Setif Tizi Ouzou Bejaia Medea Tlemcen Biskra Bechar Tebessa Skikda Jijel Mostaganem Chlef Djelfa Laghouat Ghardaia Ouargla Adrar Tamanrasset Boumerdes Tipaza Bouira Mila Guelma Khenchela Saida Relizane Mascara Tiaret Tissemsilt Naama Illizi Tindouf Msila Rouiba Kouba Boufarik Bougara Koléa Hussein-Dey Bab-Ezzouar Birtouta Draria Blida-Centre Souk-Ahras El-Tarf El-Oued El-Bayadh Ain-Defla Ain-Temouchent Sidi-Bel-Abbes Oum-El-Bouaghi Bordj-Bou-Arreridj").split(" ").map(norm));

  const lev = (a, b) => { const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]); for (let j = 1; j <= b.length; j++) d[0][j] = j; for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[a.length][b.length]; };
  const tol = (n) => (n >= 9 ? 2 : n >= 5 ? 1 : 0);

  function matchLabel(words, i) {
    let best = null, acc = "";
    for (let k = 0; k < 6 && i + k < words.length; k++) {
      if (k > 0 && /^\d+$/.test(norm(words[i + k]))) break;
      acc += norm(words[i + k]);
      if (!acc) continue;
      for (const [cat, pats] of Object.entries(LABELS)) for (const p of pats) {
        const dist = acc === p ? 0 : (acc.length >= 5 && p.length >= 5 ? lev(acc, p) : 99);
        if (dist <= (acc === p ? 0 : tol(p.length))) {
          if (!best || dist < best.dist || (dist === best.dist && k + 1 > best.len)) best = { cat, len: k + 1, dist };
        }
      }
    }
    return best;
  }

  const fixDigits = (s) => s.replace(/[Oo]/g, "0").replace(/[Il|]/g, "1");
  function findDate(v) {
    const m = v.match(/[\dOolI|]{1,4}\s*[\/\-.]\s*[\dOolI|]{1,2}\s*[\/\-.]\s*[\dOolI|]{2,4}/);
    if (!m) return null;
    const p = fixDigits(m[0]).split(/\s*[\/\-.]\s*/);
    let d, mo, y;
    if (p[0].length === 4) { y = p[0]; mo = p[1]; d = p[2]; } else { d = p[0]; mo = p[1]; y = p[2]; }
    if (y.length === 2) y = (+y > 30 ? "19" : "20") + y;
    if (+d < 1 || +d > 31 || +mo < 1 || +mo > 12 || y.length !== 4) return null;
    return { value: `${d.padStart(2, "0")}/${mo.padStart(2, "0")}/${y}`, year: +y, rest: (v.slice(0, m.index) + " " + v.slice(m.index + m[0].length)).trim() };
  }
  function findPhone(v) {
    if (!/^[\d\sOoIl|+().\-]+$/.test(v)) return null;
    if (/^[1-9]\d{8}$/.test(v.trim())) return null;
    let s = fixDigits(v).replace(/[^\d+]/g, "");
    if (/^(\+213|00213)/.test(s)) s = "0" + s.replace(/^(\+213|00213)/, "");
    else if (/^[5-7]\d{8}$/.test(s)) s = "0" + s;
    return /^0\d{8,9}$/.test(s) ? s : null;
  }
  const cleanVal = (s) => s.replace(/^[\s:：\-–—=|/]+/, "").replace(/[\s|]+$/, "").trim();
  const isCaps = (w) => w.length > 1 && w === w.toUpperCase() && /[A-ZÀ-Ý]/.test(w);
  const isName = (w) => /^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ'’\-]{1,}$/.test(w);
  const cap = (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
  const tidyName = (w) => (isCaps(w) ? cap(w) : w);

  function civility(v) {
    const n = norm(v);
    if (["monsieur", "mr", "m", "mons"].includes(n)) return "Monsieur";
    if (["madame", "mme", "mm"].includes(n)) return "Madame";
    if (["mademoiselle", "mlle", "melle", "mle"].includes(n)) return "Melle";
    return null;
  }
  function pieceType(v) {
    const n = norm(v);
    if (n === "cin" || n === "cni" || n.includes("carteidentite") || n.includes("cartenationale")) return "CIN";
    if (n.startsWith("passeport") || n === "passport") return "PASSEPORT";
    return null;
  }
  function pickAmount(str) {          // tolerant to OCR look-alikes (O/C -> 0, I/l -> 1) and "1 500"
    const t = String(str).split(/\s+/).map((x) => x.replace(/[^A-Za-z0-9]/g, ""));
    for (let i = 0; i < t.length; i++) for (const c of [t[i], t[i] + (t[i + 1] || "")]) {
      const m = c.replace(/[OoCc]/g, "0").replace(/[Il|]/g, "1");
      if (/^\d{3,5}$/.test(m) && AMOUNTS.includes(m)) return m;
    }
    return "";
  }
  function findOffer(v) {
    const n = norm(v);
    const o = OFFERS.find((x) => n.includes(norm(x)));
    if (!o) return null;
    const after = v.slice(v.toUpperCase().indexOf(o.split(" ").pop()) + 1);
    return { offer: o, amount: pickAmount(after) };
  }

  // existing: labels already collected earlier (used to pick the next free slot)
  function extract(text, existing) {
    const have = new Set(existing || []);
    const res = {};                // label -> {text, uncertain, src}
    const put = (label, val, src, uncertain) => {
      if (!val) return;
      const cur = res[label];
      if (cur && (cur.src === "label" || src !== "label")) return;   // labelled value beats guessed; first guess wins
      res[label] = { text: val, uncertain: !!uncertain, src };
    };
    const lines = String(text || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const cand = [];               // unlabeled segments, resolved after labelled ones
    const queue = [];
    const compat = (cat, v) => {
      if (!v) return false;
      const w = v.split(/\s+/);
      if (cat === "Date de naissance" || cat === "Date de délivrance") return !!findDate(v);
      if (cat === "Téléphone" || cat === "N° de contact") return !!findPhone(v);
      if (cat === "Civilité") return !!civility(v);
      if (cat === "Pièce") return !!pieceType(v);
      if (cat === "Offre") return !!findOffer(v);
      if (cat === "Montant") return !!pickAmount(v);
      if (cat === "N° pièce") return /^[A-Za-z0-9]{6,18}$/.test(v.replace(/\s/g, "")) && /\d/.test(v);
      if (cat === "Email") return /@/.test(v);
      if (cat === "Nom" || cat === "Prénom" || cat === "Lieu de naissance" || cat === "Délivrée à") return w.every(isName) && !civility(v) && !pieceType(v) && !findOffer(v);
      return true;
    };

    const handleLabeled = (cat, value) => {
      value = cleanVal(value);
      if (!value) return false;
      if (cat === "Date de naissance" || cat === "Date de délivrance") {
        const d = findDate(value); if (!d) { put(cat, value, "label"); return true; }
        put(cat, d.value, "label");
        const rest = cleanVal(d.rest.replace(/^(à|a|de)\s+/i, "").replace(/\b(à|a)\s+/i, " "));
        if (rest && isName(rest.split(" ")[0])) put(cat === "Date de naissance" ? "Lieu de naissance" : "Délivrée à", rest.replace(/^(à|a)\s+/i, ""), "label");
      } else if (cat === "Téléphone" || cat === "N° de contact") {
        const p = findPhone(value); put(cat, p || value, "label");
      } else if (cat === "Civilité") put(cat, civility(value) || value, "label");
      else if (cat === "Pièce") put(cat, pieceType(value) || value, "label");
      else if (cat === "Offre") { const o = findOffer(value); if (o) { put("Offre", o.offer, "label"); put("Montant", o.amount, "label"); } else put(cat, value, "label"); }
      else if (cat === "Montant") put(cat, pickAmount(value) || value.replace(/\s*(da|dzd)\b/i, ""), "label");
      else if (cat === "N° pièce") put(cat, fixDigits(value).replace(/\s/g, "") || value, "label");
      else if (cat === "Nom" || cat === "Prénom") put(cat, value.split(/\s+/).map(tidyName).join(" "), "label");
      else put(cat, value, "label");
      return true;
    };

    for (const line of lines) {
      const words = line.split(/\s+/);
      const segs = []; let curS = { label: null, words: [] };
      for (let i = 0; i < words.length;) {
        const m = matchLabel(words, i);
        if (m) { segs.push(curS); curS = { label: m.cat, words: [] }; i += m.len; } else curS.words.push(words[i++]);
      }
      segs.push(curS);
      segs.filter((s) => s.label || s.words.length).forEach((s, idx, arr) => {
        const v = s.words.join(" ");
        if (s.label) { if (!handleLabeled(s.label, v)) queue.push(s.label); }
        else {
          const vv = cleanVal(v), qi = queue.findIndex((c) => compat(c, vv));
          if (qi >= 0) handleLabeled(queue.splice(qi, 1)[0], vv); else cand.push(vv);
        }
      });
    }
    Object.keys(res).forEach((k) => have.add(k));

    // ---- unlabeled values: recognise by content ----
    const dates = [], rest = [];
    cand.forEach((v) => {
      if (!v) return;
      if (/^profil\b/i.test(v)) return;
      const email = v.match(/[\w.+-]+@[\w-]+\.[\w.-]+/); if (email) return put("Email", email[0], "content");
      const d = findDate(v); if (d) { dates.push(d); const r = cleanVal(d.rest.replace(/^(à|a)\s+/i, "")); if (r && isName(r.split(" ")[0])) rest.push(r); return; }
      const ph = findPhone(v);
      if (ph) { dates.length; return rest.push({ phone: ph }); }
      const c = civility(v); if (c) return put("Civilité", c, "content");
      const pt = pieceType(v); if (pt) return put("Pièce", pt, "content");
      const o = findOffer(v); if (o) { put("Offre", o.offer, "content"); put("Montant", o.amount, "content"); return; }
      if (/^\d[\d\s]{1,5}\s*(da|dzd)$/i.test(v)) { const a = v.replace(/\D/g, ""); if (AMOUNTS.includes(a)) return put("Montant", a, "content"); }
      const digits = fixDigits(v).replace(/[\s.\-]/g, "");
      if (/^\d{8,18}$/.test(digits)) return put("N° pièce", digits, "content");
      rest.push(v);
    });
    // dates
    const hasB = () => have.has("Date de naissance"), hasD = () => have.has("Date de délivrance");
    const give = (d, label) => { put(label, d.value, "content"); have.add(label); };
    if (dates.length >= 2 && !hasB() && !hasD()) { const s = dates.slice().sort((a, b) => a.year - b.year); give(s[0], "Date de naissance"); give(s[s.length - 1], "Date de délivrance"); }
    else dates.forEach((d) => { if (!hasB() && (hasD() || d.year <= 2010)) give(d, "Date de naissance"); else if (!hasD()) give(d, "Date de délivrance"); else give(d, "Date de délivrance"); });
    // phones
    rest.filter((x) => x.phone).forEach((x) => {
      const p = x.phone;
      let label = /^06/.test(p) && !have.has("Téléphone") ? "Téléphone" : !have.has("N° de contact") ? "N° de contact" : !have.has("Téléphone") ? "Téléphone" : "N° de contact";
      put(label, p, "content"); have.add(label);
    });
    // names and places
    const slot = (label, v, unc) => { put(label, v, "content", unc); have.add(label); };
    const placeSlot = (v) => slot(have.has("Lieu de naissance") ? "Délivrée à" : "Lieu de naissance", v, false);
    rest.filter((x) => typeof x === "string").forEach((v) => {
      const w = v.split(/\s+/).filter(Boolean);
      if (!w.length || !w.every((x) => isName(x))) { if (v.length >= 2) put("Texte", v, "content", true); return; }
      const nw = w.map(norm);
      const known = ["Nom", "Prénom"].map((l) => res[l] && norm(res[l].text));
      if (nw.every((x) => known.some((k) => k && k.includes(x)))) return;   // heading repeating a labelled name
      if (PLACES.has(nw.join("")) || PLACES.has(nw[0])) return placeSlot(w.map(tidyName).join(" "));
      if (nw.every((x) => FIRST.has(x))) return slot("Prénom", w.map(tidyName).join(" "), false);
      if (nw.every((x) => SURN.has(x))) return slot("Nom", w.map(tidyName).join(" "), false);
      if (w.length === 1) {
        if (SURN.has(nw[0])) return slot("Nom", tidyName(w[0]), false);
        if (FIRST.has(nw[0])) return slot("Prénom", tidyName(w[0]), false);
        const hasN = have.has("Nom"), hasP = have.has("Prénom");
        if (hasN && hasP) return placeSlot(tidyName(w[0]));
        if (hasN) return slot("Prénom", tidyName(w[0]), true);
        if (hasP) return slot("Nom", tidyName(w[0]), true);
        return slot("Nom", tidyName(w[0]), true);
      }
      // 2+ words
      if (have.has("Nom") && have.has("Prénom") && !nw.some((x) => FIRST.has(x) || SURN.has(x))) return placeSlot(w.map(tidyName).join(" "));
      if (SURN.has(nw[0]) && nw.slice(1).every((x) => FIRST.has(x))) { slot("Nom", tidyName(w[0]), false); return slot("Prénom", w.slice(1).map(tidyName).join(" "), false); }
      if (FIRST.has(nw[0]) && SURN.has(nw[nw.length - 1])) { slot("Prénom", w.slice(0, -1).map(tidyName).join(" "), false); return slot("Nom", tidyName(w[w.length - 1]), false); }
      if (isCaps(w[0]) && !isCaps(w[1])) { slot("Nom", cap(w[0]), false); return slot("Prénom", w.slice(1).join(" "), false); }
      if (!isCaps(w[0]) && isCaps(w[w.length - 1])) { slot("Prénom", w.slice(0, -1).join(" "), false); return slot("Nom", cap(w[w.length - 1]), false); }
      if (w.length === 2 && !have.has("Nom") && !have.has("Prénom")) { slot("Nom", tidyName(w[0]), true); return slot("Prénom", tidyName(w[1]), true); }
      put("Texte", v, "content", true);
    });

    let out = CATS.filter((c) => res[c]).map((c) => ({ label: c, text: res[c].text, uncertain: res[c].uncertain }));
    if (out.filter((o) => o.label !== "Texte").length >= 3) out = out.filter((o) => o.label !== "Texte");
    return out;
  }

  const api = { extract, CATS, norm, matchLabel, civility, pieceType, findOffer, pickAmount, OFFERS, AMOUNTS };
  root.OCRClassify = api;
  if (typeof module !== "undefined") module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
