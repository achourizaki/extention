(() => {
  if (window.__ocrCaptureLoaded) return;
  window.__ocrCaptureLoaded = true;

  function toast(text) {
    const t = document.createElement("div");
    t.textContent = text;
    Object.assign(t.style, {
      position: "fixed", bottom: "24px", right: "24px", zIndex: 2147483647,
      background: "#111827", color: "#fff", padding: "10px 14px", borderRadius: "8px",
      font: "14px system-ui, sans-serif", maxWidth: "360px", boxShadow: "0 4px 16px rgba(0,0,0,.3)"
    });
    document.documentElement.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  }

  function startSelect() {
    const overlay = document.createElement("div");
    Object.assign(overlay.style, {
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0, zIndex: 2147483647, cursor: "crosshair",
      background: "rgba(0,0,0,.25)"
    });
    const box = document.createElement("div");
    Object.assign(box.style, {
      position: "fixed", border: "2px solid #2563eb", background: "rgba(37,99,235,.15)", display: "none"
    });
    const hint = document.createElement("div");
    hint.textContent = "Dessinez un cadre autour du texte (une valeur ou toute la fiche). Échap pour annuler.";
    Object.assign(hint.style, {
      position: "fixed", top: "12px", left: "50%", transform: "translateX(-50%)",
      background: "#111827", color: "#fff", padding: "6px 12px", borderRadius: "6px",
      font: "13px system-ui, sans-serif"
    });
    overlay.append(box, hint);
    document.documentElement.appendChild(overlay);

    let sx, sy, drawing = false;
    const cleanup = () => { overlay.remove(); document.removeEventListener("keydown", onKey, true); };
    const onKey = (e) => { if (e.key === "Escape") cleanup(); };
    document.addEventListener("keydown", onKey, true);

    overlay.addEventListener("mousedown", (e) => {
      e.preventDefault(); drawing = true; sx = e.clientX; sy = e.clientY;
      box.style.display = "block";
    });
    overlay.addEventListener("mousemove", (e) => {
      if (!drawing) return;
      const x = Math.min(sx, e.clientX), y = Math.min(sy, e.clientY);
      Object.assign(box.style, {
        left: x + "px", top: y + "px",
        width: Math.abs(e.clientX - sx) + "px", height: Math.abs(e.clientY - sy) + "px"
      });
    });
    overlay.addEventListener("mouseup", (e) => {
      if (!drawing) return;
      drawing = false;
      const rect = {
        x: Math.min(sx, e.clientX), y: Math.min(sy, e.clientY),
        w: Math.abs(e.clientX - sx), h: Math.abs(e.clientY - sy)
      };
      cleanup();
      if (rect.w < 5 || rect.h < 5) return;
      // wait for the overlay to disappear before the screenshot
      setTimeout(() => {
        browser.runtime.sendMessage({ type: "captured", rect, dpr: window.devicePixelRatio });
        toast("Lecture du texte…");
      }, 150);
    });
  }

  browser.runtime.onMessage.addListener((msg) => {
    if (msg.type === "start-select") startSelect();
    if (msg.type === "capture-page") {
      browser.runtime.sendMessage({ type: "captured", rect: { x: 0, y: 0, w: window.innerWidth, h: window.innerHeight }, dpr: window.devicePixelRatio });
      toast("Analyse de la page…");
    }
    if (msg.type === "toast") toast(msg.text);
  });
})();
