// Finds where values go in ANY form (PDF text layer / scanned page words / Word paragraphs):
//  "Nom : ........"  ->  text field,   "|__|__|__|"  ->  digit cells,   "[] Monsieur"  ->  checkbox
(function (root) {
  const C = () => root.OCRClassify;
  const GLYPH = "□☐❑◻▢";
  const GLYPH_RE = new RegExp("[" + GLYPH + "]");
  const letters = (s) => (String(s).match(/[A-Za-zÀ-ÿ]/g) || []).length;
  const norm = (s) => C().norm(s);

  // ---- split a piece of text into tokens: word | glyph | run ----
  // pos(ci) gives the x coordinate of character index ci (PDF: proportional, Word: the index itself)
  function tokenize(str, pos, base) {
    const toks = [];
    const re = new RegExp("[" + GLYPH + "]|[^\\s" + GLYPH + "]+", "g");
    let m;
    while ((m = re.exec(str))) {
      const s = m[0], a = m.index;
      const mk = (type, text, ci) => toks.push(Object.assign({ type, s: text, x0: pos(ci), x1: pos(ci + text.length), ci0: ci, ci1: ci + text.length }, base));
      if (GLYPH_RE.test(s) && s.length === 1) { mk("glyph", s, a); continue; }
      if (/^[|._…·]{3,}$/.test(s) && (/[._…·]{3,}/.test(s) || (/\|/.test(s) && (s.match(/[._…·]+/g) || []).length >= 2))) { mk("run", s, a); continue; }
      const r = s.match(/^(.*?[^|._…·\s])([|._…·]{4,})$/);          // "Nom/........" -> word + run
      if (r && /[._…·]{3,}/.test(r[2])) { mk("word", r[1], a); mk("run", r[2], a + r[1].length); continue; }
      mk("word", s, a);
    }
    return toks;
  }

  // ---- options of a checkbox group ----
  function optionOf(text) {
    const c = C();
    const cv = c.civility(text); if (cv) return { key: "Civilité", value: cv };
    const pt = c.pieceType(text); if (pt) return { key: "Pièce", value: pt };
    const o = c.findOffer(text); if (o) return { key: "Offre", value: o.offer };
    if (norm(text) === "autre") return { key: "Offre", value: "Autre" };
    const n = String(text).replace(/\s/g, "");
    if (c.AMOUNTS.includes(n)) return { key: "Montant", value: n };
    return null;
  }

  const cellsOf = (run) => {            // "|__|__|__|" -> [{a,b}] character ranges of every cell
    if (run.indexOf("|") < 0) return null;
    const out = []; const re = /[_.…·]+/g; let m;
    while ((m = re.exec(run))) out.push({ a: m.index, b: m.index + m[0].length });
    return out.length >= 2 ? out : null;
  };

  // ---- the heart: one visual line -> list of field descriptors ----
  function analyzeLine(toks, opt) {
    opt = opt || {};
    const c = C(), out = [], usedRun = new Set();
    const T = [];
    toks.slice().sort((a, b) => a.x0 - b.x0).forEach((t) => {
      const p = T[T.length - 1];
      if (p && p.type === "word" && t.type === "word" && letters(p.s) && letters(t.s) && t.x0 - p.x1 < 0.9 && Math.abs((p.y || 0) - (t.y || 0)) < 1) T[T.length - 1] = Object.assign({}, p, { s: p.s + t.s, x1: t.x1, ci1: t.ci1 });
      else T.push(t);
    });
    const isLatin = (t) => t.type === "word" && letters(t.s) > 0;
    const L = T.filter(isLatin);
    const SOFT = /^(a|à|le|la|de|du|des|n°|no|dd|mm|yy)$/i;
    const blocker = (t) => isLatin(t) && letters(t.s) >= 2 && !SOFT.test(t.s.replace(/[^A-Za-zÀ-ÿ°]/g, ""));
    // 1) known labels
    const labels = [];
    for (let i = 0; i < L.length;) {
      const m = c.matchLabel(L.map((t) => t.s), i);
      if (m) { labels.push({ cat: m.cat, a: L[i], b: L[i + m.len - 1], idx: i }); i += m.len; } else i++;
    }
    const mkText = (key, run, extra) => {
      if (run.cellsX) {
        const phone = /^(Téléphone|N° de contact)$/.test(key);
        return Object.assign({ kind: "cells", key, run, n: run.cellsX.length, chunk: phone ? 2 : 1, x0: run.cellsX[0].x0, x1: run.cellsX[run.cellsX.length - 1].x1, cells: run.cellsX }, extra);
      }
      const cells = cellsOf(run.s);
      if (cells) {
        const phone = /^(Téléphone|N° de contact)$/.test(key);
        const x = (ci) => run.x0 + (run.x1 - run.x0) * ci / run.s.length;
        return Object.assign({ kind: "cells", key, run, n: cells.length, chunk: phone ? 2 : 1, x0: x(cells[0].a), x1: x(cells[cells.length - 1].b), cells: cells.map((k) => ({ x0: x(k.a), x1: x(k.b), ci0: run.ci0 + k.a, ci1: run.ci0 + k.b })) }, extra);
      }
      return Object.assign({ kind: "text", key, run, x0: run.x0, x1: run.x1 }, extra);
    };
    labels.forEach((lab, k) => {
      const next = labels[k + 1];
      const zone = T.filter((t) => t.x0 >= lab.b.x1 - (opt.ocr ? 12 : 0.5) && (!next || t.x0 < next.a.x0 - 0.5));
      const run = zone.find((t) => t.type === "run"), glyph = zone.find((t) => t.type === "glyph");
      if (glyph && (!run || glyph.x0 < run.x0)) return;                          // a checkbox-group label
      const upto = run ? zone.filter((t) => t.x0 < run.x0) : zone;
      if (opt.ocr ? upto.filter((t) => blocker(t) && letters(t.s) >= 3).length >= 3 : upto.some(blocker)) return;   // a sentence, not a label
      if (run) {
        usedRun.add(run);
        const f = mkText(lab.cat, run, { label: lab.b }); out.push(f);
        if (/^Date de (naissance|délivrance)$/.test(lab.cat)) {                     // "...... A / ......."
          const after = zone.filter((t) => t.x0 > run.x1);
          const sep = after.find((t) => t.type === "word" && /^(a|à|at)$/i.test(t.s.replace(/[^A-Za-zÀ-ÿ]/g, "")));
          const run2 = sep && after.find((t) => t.type === "run" && t.x0 > sep.x1);
          if (run2) { usedRun.add(run2); out.push(mkText(lab.cat === "Date de naissance" ? "Lieu de naissance" : "Délivrée à", run2, { label: sep })); }
        }
      } else if (lab.idx === 0 && !zone.some((t) => t.type === "word" && letters(t.s) > 0)) {
        out.push({ kind: "after", key: lab.cat, label: lab.b, x0: lab.b.x1 + 4, nextX: next ? next.a.x0 : null });
      }
    });
    // 2) runs that follow an unknown label: "Profession : ......"  /  "DATE ___|___|____"
    T.filter((t) => t.type === "run" && !usedRun.has(t)).forEach((r) => {
      const dateOnly = !!opt.ocr;
      const left = T.filter((t) => t.x1 <= r.x0 + 0.5);
      const words = [];
      for (let i = left.length - 1; i >= 0 && words.length < 4; i--) {
        const t = left[i];
        if (t.type === "run" || t.type === "glyph") break;
        if (isLatin(t)) words.unshift(t); else if (words.length && t.type === "word" && !/^[:\/|\-–]*$/.test(t.s) && letters(t.s) === 0) break;
      }
      if (!words.length) return;
      const key = words.map((w) => w.s).join(" ").replace(/[:\/|]+/g, "").trim();
      if (!key || (dateOnly && norm(key) !== "date")) return;
      const cells = r.cellsX ? null : cellsOf(r.s);
      if (norm(key) === "date" && ((cells && cells.length === 3) || (r.cellsX && r.cellsX.length === 3))) {
        ["day", "month", "year"].forEach((part, i) => {
          const x = (ci) => r.x0 + (r.x1 - r.x0) * ci / r.s.length;
          const c = r.cellsX ? r.cellsX[i] : { x0: x(cells[i].a), x1: x(cells[i].b) };
          out.push({ kind: "text", key: "Date", part, run: r, label: words[words.length - 1], x0: c.x0, x1: c.x1, ci0: cells ? r.ci0 + cells[i].a : undefined, ci1: cells ? r.ci0 + cells[i].b : undefined });
        });
        return;
      }
      out.push(mkText(key, r, { label: words[words.length - 1], generic: true }));
    });
    // 3) checkboxes: each glyph takes the nearest recognised option word(s)
    const glyphs = T.filter((t) => t.type === "glyph");
    if (glyphs.length) {
      const W = T.filter((t) => t.type === "word" && /[A-Za-zÀ-ÿ0-9]/.test(t.s));
      const opts = [];
      for (let i = 0; i < W.length; i++) {
        let best = null;
        for (let n = 1; n <= 4 && i + n <= W.length; n++) {
          if (n > 1 && glyphs.some((g) => g.x0 > W[i + n - 2].x1 - 0.5 && g.x1 < W[i + n - 1].x0 + 0.5)) break;
          const txt = W.slice(i, i + n).map((w) => w.s).join(" "), o = optionOf(txt);
          if (o) best = Object.assign({ x0: W[i].x0, x1: W[i + n - 1].x1 }, o);
        }
        if (best) opts.push(best);
      }
      const pairs = [];
      glyphs.forEach((g) => opts.forEach((o) => {
        const gap = o.x0 >= g.x1 - 1 ? o.x0 - g.x1 : g.x0 - o.x1;
        if (o.x0 >= g.x1 - 1 || o.x1 <= g.x0 + 1) pairs.push({ g, o, gap: Math.max(0, gap) });
      }));
      pairs.sort((a, b) => a.gap - b.gap);
      const gu = new Set(), ou = new Set(), picked = [];
      pairs.forEach((p) => { if (gu.has(p.g) || ou.has(p.o) || p.gap > 450) return; gu.add(p.g); ou.add(p.o); picked.push(p); });
      const offers = picked.filter((p) => p.o.key === "Offre").concat(opts.filter((o) => o.key === "Offre" && !ou.has(o)).map((o) => ({ o })));
      picked.forEach((p) => {
        const f = { kind: "check", key: p.o.key, match: p.o.value, glyph: p.g };
        if (p.o.key === "Montant") {
          const row = offers.map((q) => q.o).filter((o) => o.x1 <= p.g.x0 + 2).sort((a, b) => b.x1 - a.x1)[0];
          if (row) { f.whenKey = "Offre"; f.whenVal = row.value; }
        }
        out.push(f);
      });
    }
    return out;
  }

  // ---- PDF: items of the text layer -> tokens -> fields (box geometry in PDF points, origin top-left) ----
  function tokenizeItem(str, it, measure) {
    const full = measure ? measure(str) : str.length;
    const pos = (ci) => it.x + it.w * (full > 0 ? (measure ? measure(str.slice(0, ci)) : ci) / full : ci / Math.max(1, str.length));
    return tokenize(str, pos, { y: it.base, size: it.size });
  }
  async function extractPdfPages(pdfDoc, measure) {
    const pages = [];
    for (let p = 1; p <= pdfDoc.numPages; p++) {
      const page = await pdfDoc.getPage(p), v = page.view, tc = await page.getTextContent(), toks = [];
      for (const it of tc.items) {
        if (!it.str || !it.str.trim() || Math.abs(it.transform[1]) > 0.1) continue;
        tokenizeItem(it.str, { x: it.transform[4] - v[0], w: it.width, base: v[3] - it.transform[5], size: Math.abs(it.transform[3]) || it.height || 10 }, measure).forEach((t) => toks.push(t));
      }
      pages.push({ width: v[2] - v[0], height: v[3] - v[1], tokens: toks });
    }
    return pages;
  }
  function groupLines(tokens, opt) {
    opt = opt || {};
    const sorted = tokens.slice().sort((a, b) => a.y - b.y), lines = [];
    sorted.forEach((t) => {
      const l = lines.find((l) => Math.abs(l.y - t.y) <= Math.max(opt.tol || 2.5, t.size * 0.35));
      if (l) l.toks.push(t); else lines.push({ y: t.y, toks: [t] });
    });
    return lines;
  }
  function pdfFields(pages) {
    const fields = []; let n = 0;
    pages.forEach((pg, pi) => groupLines(pg.tokens, { tol: pg.ocr ? 4.5 : 2.5 }).forEach((line) => analyzeLine(line.toks, { ocr: pg.ocr }).forEach((d) => {
      const base = (d.run || d.label || d.glyph || line.toks[0]), size = Math.min(11, Math.max(8, base.size || 10));
      if (pg.ocr && ((d.kind === "text" && d.x1 - d.x0 < 40) || (d.kind === "cells" && d.x1 - d.x0 < 60) || (d.kind === "after"))) return;
      if ((d.run || d.glyph || d.label).y > pg.height - 40) return;           // footers / letterheads
      const f = { id: "a" + (++n), key: d.key, page: pi };
      if (d.kind === "check") {
        const cx = (d.glyph.x0 + d.glyph.x1) / 2, cy = d.glyph.y - d.glyph.size * 0.33;
        Object.assign(f, { type: "check", match: d.match, x: cx - 3.5, y: cy - 3.5, w: 7, h: 7 });
        if (d.whenKey) { f.whenKey = d.whenKey; f.whenVal = d.whenVal; }
      } else if (d.kind === "after") {
        const right = d.nextX ? d.nextX - 4 : pg.width - 36;
        if (right - d.x0 < 50) return;
        Object.assign(f, { type: "text", x: d.x0, y: d.label.y - 10.5, w: right - d.x0, h: 11, size });
      } else if (d.kind === "cells") {
        Object.assign(f, { type: "cells", x: d.x0, y: d.run.y - 10.5, w: d.x1 - d.x0, h: 11, size, cells: d.n, chunk: d.chunk });
      } else {
        Object.assign(f, { type: "text", x: d.x0, y: d.run.y - 10.5, w: Math.max(20, d.x1 - d.x0), h: 11, size });
        if (d.part) f.part = d.part;
      }
      fields.push(f);
    })));
    return fields;
  }

  // ---- scanned pages: OCR words -> same tokens (units: PDF points) ----
  function wordsToPages(ocrPages) {
    return ocrPages.map((pg) => {
      const toks = [];
      pg.words.forEach((w) => {
        const txt = w.text.trim(); if (!txt) return;
        const t = tokenize(txt, (ci) => w.x0 + (w.x1 - w.x0) * ci / txt.length, { y: w.base, size: w.size });
        t.forEach((x) => toks.push(x));
      });
      return { width: pg.width, height: pg.height, tokens: toks };
    });
  }

  function scanPages(scans) {          // scans: [{width,height(pt), words:[{text,x0,x1,base,size}], runs:[{x0,x1,y,cellsX}], boxes:[{x0,x1,y0,y1}]}] in PDF points
    const AM = root.OCRClassify.AMOUNTS;
    return scans.map((sc) => {
      const toks = [];
      sc.words.forEach((w) => {
        let txt = w.text.trim(); if (!txt) return;
        for (let k = 0; k <= 3 && k < txt.length; k++) { const suf = txt.slice(k); if (AM.indexOf(suf) >= 0) { if (k) { w = Object.assign({}, w, { x0: w.x0 + (w.x1 - w.x0) * k / txt.length }); txt = suf; } break; } }
        tokenize(txt, (ci) => w.x0 + (w.x1 - w.x0) * ci / txt.length, { y: w.base, size: w.size }).forEach((x) => { if (x.type === "word") toks.push(x); });   // runs/boxes come from the image only
      });
      sc.runs.forEach((r) => toks.push({ type: "run", s: r.cellsX ? "|" + r.cellsX.map(() => "_____").join("|") + "|" : "." .repeat(Math.max(4, Math.round((r.x1 - r.x0) / 3))), x0: r.x0, x1: r.x1, ci0: 0, ci1: 0, y: r.y, size: 10, cellsX: r.cellsX }));
      sc.boxes.forEach((b) => toks.push({ type: "glyph", s: "□", x0: b.x0, x1: b.x1, ci0: 0, ci1: 1, y: (b.y0 + b.y1) / 2 + 3.3, size: 10 }));
      return { width: sc.width, height: sc.height, tokens: toks, ocr: true };
    });
  }

  // ---- Word (.docx): analyse the text of one paragraph; x = character index ----
  function docParagraph(text) { return analyzeLine(tokenize(text, (ci) => ci, { y: 0, size: 10 }), {}); }

  root.OCRDetect = { tokenize, analyzeLine, extractPdfPages, pdfFields, wordsToPages, scanPages, docParagraph, GLYPH };
  if (typeof module !== "undefined") module.exports = root.OCRDetect;
})(typeof window !== "undefined" ? window : globalThis);
