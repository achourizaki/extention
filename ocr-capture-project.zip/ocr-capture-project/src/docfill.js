// Word (.docx): finds "Nom : ........" / table label cells / checkboxes in the document itself and fills them.
(function (root) {
  const NS = {};
  const g = (el, name) => Array.prototype.slice.call(el.getElementsByTagName(name));
  const kids = (el) => Array.prototype.slice.call(el.childNodes).filter((n) => n.nodeType === 1);

  function paragraphInfo(p) {            // text of a paragraph + where every character lives
    const segs = []; let text = "";
    const walk = (n) => {
      kids(n).forEach((c) => {
        if (c.nodeName === "w:t") { const t = c.textContent; segs.push({ node: c, start: text.length, end: text.length + t.length }); text += t; }
        else if (c.nodeName === "w:tab" || c.nodeName === "w:br") { segs.push({ node: null, start: text.length, end: text.length + 1 }); text += " "; }
        else walk(c);
      });
    };
    walk(p);
    return { text, segs };
  }
  function replaceRange(segs, a, b, rep) {
    let done = false;
    segs.forEach((s) => {
      if (!s.node) return;
      const lo = Math.max(a, s.start), hi = Math.min(b, s.end);
      if (lo >= hi) return;
      const t = s.node.textContent;
      s.node.textContent = t.slice(0, lo - s.start) + (done ? "" : rep) + t.slice(hi - s.start);
      s.node.setAttribute("xml:space", "preserve"); done = true;
    });
    return done;
  }
  function appendText(doc, p, text) {
    const runs = g(p, "w:r"), last = runs[runs.length - 1];
    const r = last ? last.cloneNode(true) : doc.createElement("w:r");
    kids(r).forEach((c) => { if (c.nodeName !== "w:rPr") r.removeChild(c); });
    const t = doc.createElement("w:t"); t.setAttribute("xml:space", "preserve"); t.appendChild(doc.createTextNode(text)); r.appendChild(t);
    p.appendChild(r);
  }
  const nextCell = (p) => {
    const tc = p.parentNode && p.parentNode.nodeName === "w:tc" ? p.parentNode : null;
    if (!tc) return null;
    let n = tc.nextSibling; while (n && !(n.nodeType === 1 && n.nodeName === "w:tc")) n = n.nextSibling;
    if (!n) return null;
    const empty = g(n, "w:t").every((t) => !t.textContent.trim());
    return empty ? n : null;
  };

  // values === null -> only collect keys; otherwise fill
  function process(doc, values) {
    const keys = [], norm = (s) => root.OCRClassify.norm(s), N = (v) => norm(v);
    const addKey = (key, kind, opt) => {
      let k = keys.find((x) => x.key === key);
      if (!k) { k = { key, kind: "text", options: [] }; keys.push(k); }
      if (kind === "select") { k.kind = "select"; if (opt != null && k.options.indexOf(opt) < 0) k.options.push(opt); }
    };
    const usedCells = new Set();
    g(doc.documentElement, "w:p").forEach((p) => {
      const info = paragraphInfo(p);
      if (!info.text.trim()) return;
      const descs = root.OCRDetect.docParagraph(info.text);
      const ops = [];
      descs.forEach((d) => {
        if (d.kind === "check") { addKey(d.key, "select", d.match); }
        else addKey(d.key, "text");
        if (!values) return;
        const when = d.whenKey ? N(values[d.whenKey]) === N(d.whenVal) : true;
        if (!when) return;
        const v = values[d.key]; if (v == null || String(v).trim() === "") return;
        if (d.kind === "check") { if (N(v) === N(d.match)) ops.push({ a: d.glyph.ci0, b: d.glyph.ci1, rep: "☒" }); }
        else if (d.kind === "cells") {
          const dg = String(v).replace(/[^\dA-Za-z]/g, "");
          d.cells.forEach((c, i) => { const part = dg.slice(i * d.chunk, (i + 1) * d.chunk); if (part) ops.push({ a: c.ci0, b: c.ci1, rep: part }); });
        } else if (d.kind === "text") {
          let val = String(v);
          if (d.part) { const m = val.match(/(\d{1,4})\D+(\d{1,2})\D+(\d{1,4})/); if (!m) return; const y4 = m[1].length === 4; val = ({ day: y4 ? m[3] : m[1], month: m[2], year: y4 ? m[1] : m[3] })[d.part]; }
          ops.push({ a: d.ci0 != null ? d.ci0 : d.run.ci0, b: d.ci1 != null ? d.ci1 : d.run.ci1, rep: val });
        } else if (d.kind === "after") {
          const cell = nextCell(p);
          if (cell && !usedCells.has(cell)) {
            usedCells.add(cell);
            const cp = g(cell, "w:p")[0] || null;
            if (cp) appendText(doc, cp, String(v));
          } else ops.push({ append: String(v), a: info.text.length });
        }
      });
      ops.sort((x, y) => y.a - x.a).forEach((o) => { if (o.append != null) appendText(doc, p, " " + o.append); else replaceRange(info.segs, o.a, o.b, o.rep); });
    });
    return keys;
  }

  const parse = (xml) => new (root.DOMParser || DOMParser)().parseFromString(xml, "application/xml");
  const ser = (doc) => new (root.XMLSerializer || XMLSerializer)().serializeToString(doc);
  function load(bytes) { return new root.PizZip(bytes); }
  const PARTS = ["word/document.xml"];

  root.OCRDoc = {
    analyze(bytes) { const z = load(bytes); return process(parse(z.file(PARTS[0]).asText()), null); },
    fill(bytes, values) {
      const z = load(bytes);
      PARTS.forEach((n) => { const f = z.file(n); if (!f) return; const doc = parse(f.asText()); process(doc, values); z.file(n, ser(doc)); });
      return z;
    }
  };
  if (typeof module !== "undefined") module.exports = root.OCRDoc;
})(typeof window !== "undefined" ? window : globalThis);
