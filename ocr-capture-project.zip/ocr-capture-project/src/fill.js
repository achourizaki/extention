(function (root) {
  function norm(s) {
    return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
  }
  function parseDate(v) {
    const m = String(v || "").match(/(\d{1,4})\s*[\/\-. ]\s*(\d{1,2})\s*[\/\-. ]\s*(\d{1,4})/);
    if (!m) return null;
    let d, mo, y;
    if (m[1].length === 4) { y = m[1]; mo = m[2]; d = m[3]; } else { d = m[1]; mo = m[2]; y = m[3]; }
    if (y.length === 2) y = (+y > 30 ? "19" : "20") + y;
    return { day: d.padStart(2, "0"), month: mo.padStart(2, "0"), year: y };
  }

  async function fillPdf(PDFLib, bytes, fields, values, opts) {
    opts = opts || {};
    const { PDFDocument, StandardFonts, rgb } = PDFLib;
    const doc = await PDFDocument.load(bytes);
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const safe = (s) => [...String(s).replace(/[’‘]/g, "'").replace(/[“”]/g, '"')]
      .map((c) => { try { font.encodeText(c); return c; } catch (e) { return "?"; } }).join("");

    // real form fields (if the PDF has them)
    try {
      const form = doc.getForm();
      for (const f of form.getFields()) {
        const name = f.getName();
        const v = values[name];
        if (v == null || v === "") continue;
        const t = f.constructor.name;
        if (t === "PDFTextField") f.setText(safe(v));
        else if (t === "PDFCheckBox") { if (!/^(no|non|0|false|)$/i.test(String(v).trim())) f.check(); }
        else if (t === "PDFDropdown" || t === "PDFRadioGroup") {
          const o = f.getOptions().find((x) => norm(x) === norm(v));
          if (o) f.select(o);
        }
      }
    } catch (e) { /* no form */ }

    const pages = doc.getPages();
    for (const f of fields || []) {
      const page = pages[f.page || 0];
      if (!page) continue;
      if (f.whenKey && norm(values[f.whenKey]) !== norm(f.whenVal)) continue;
      let v = values[f.key];
      if (v == null || String(v).trim() === "") continue;
      v = String(v).trim();
      const H = page.getHeight();
      if (f.type === "check") {
        if (norm(v) !== norm(f.match)) continue;
        const i = Math.min(1.4, f.w * 0.2);
        const o = { thickness: 1.3, color: rgb(0, 0, 0) };
        page.drawLine({ ...o, start: { x: f.x + i, y: H - (f.y + i) }, end: { x: f.x + f.w - i, y: H - (f.y + f.h - i) } });
        page.drawLine({ ...o, start: { x: f.x + i, y: H - (f.y + f.h - i) }, end: { x: f.x + f.w - i, y: H - (f.y + i) } });
        continue;
      }
      if (f.part) {
        const d = parseDate(v);
        if (!d) continue;
        v = d[f.part];
      }
      if (f.type === "cells") {
        const digits = v.replace(/[^\dA-Za-z]/g, "");
        const n = f.cells || 5, ch = f.chunk || 2, cw = f.w / n;
        const sz = f.size || 10;
        for (let i = 0; i < n; i++) {
          const part = digits.slice(i * ch, (i + 1) * ch);
          if (!part) break;
          const w = font.widthOfTextAtSize(part, sz);
          page.drawText(part, { x: f.x + i * cw + (cw - w) / 2, y: H - (f.y + f.h / 2) - sz * 0.35, size: sz, font, color: rgb(0, 0, 0) });
        }
        continue;
      }
      const txt = safe(v);
      let sz = f.size || 10;
      while (sz > 5 && font.widthOfTextAtSize(txt, sz) > f.w - 2) sz -= 0.5;
      page.drawText(txt, { x: f.x + 2, y: H - (f.y + f.h / 2) - sz * 0.35, size: sz, font, color: rgb(0, 0, 0) });
    }
    return await doc.save();
  }


  const ALIASES = [
    ["nom", "name", "lastname", "surname", "famille"],
    ["prenom", "firstname", "givenname"],
    ["datedenaissance", "naissance", "birthday", "birth", "dob", "birthdate", "datebirthday"],
    ["lieudenaissance", "birthplace", "placeofbirth"],
    ["telephone", "phone", "tel", "mobile", "numerodetelephone"],
    ["ndecontact", "contact", "numerodecontact"],
    ["npiece", "numerodelapiece", "numeropiece", "idnumber", "idno"],
    ["datededelivrance", "delivreele", "issuedate", "datedelivrance"],
    ["delivreea", "lieudedelivrance", "issueplace"],
    ["email", "mail", "courriel"]
  ];
  const groupOf = (n) => ALIASES.find((g) => g.includes(n));
  function today() {
    const d = new Date();
    return [String(d.getDate()).padStart(2, "0"), String(d.getMonth() + 1).padStart(2, "0"), d.getFullYear()].join("/");
  }
  // keys: [{key, kind:'text'|'select', options:[]}], items: [{id,label,text}]
  function autoMatch(keys, items, existing) {
    const used = new Set(), nv = { ...(existing || {}) };
    keys.forEach((k) => {
      if (nv[k.key]) return;
      const nk = norm(k.key), g = groupOf(nk) || [nk];
      if (k.kind === "select") {
        const byLabel = items.find((it) => norm(it.label) === nk && k.options.some((o) => norm(o) === norm(it.text)));
        if (byLabel) { nv[k.key] = k.options.find((o) => norm(o) === norm(byLabel.text)); used.add(byLabel.id); return; }
        const hit = items.find((it) => k.options.some((o) => norm(o) === norm(it.text)));
        if (hit) { nv[k.key] = k.options.find((o) => norm(o) === norm(hit.text)); used.add(hit.id); }
        return;
      }
      const it = items.find((i) => !used.has(i.id) && (g.includes(norm(i.label)) || norm(i.label) === nk));
      if (it) { nv[k.key] = it.text; used.add(it.id); }
      else if (nk === "date") nv[k.key] = today();
    });
    return nv;
  }

  const api = { norm, parseDate, fillPdf, autoMatch, today };
  root.OCRFill = api;
  if (typeof module !== "undefined") module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
