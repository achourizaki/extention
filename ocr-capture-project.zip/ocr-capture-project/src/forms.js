const $ = (id) => document.getElementById(id);
const { norm, fillPdf } = OCRFill;
pdfjsLib.GlobalWorkerOptions.workerSrc = "lib/pdf.worker.min.js";

/* ---------- storage (IndexedDB keeps the uploaded forms) ---------- */
function openDb() {
  return new Promise((res, rej) => {
    const r = indexedDB.open("ocr-forms", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("templates", { keyPath: "id" });
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function tx(mode, fn) {
  const d = await openDb();
  return new Promise((res, rej) => {
    const t = d.transaction("templates", mode);
    const req = fn(t.objectStore("templates"));
    t.oncomplete = () => res(req && req.result);
    t.onerror = () => rej(t.error);
  });
}
const dbAll = () => tx("readonly", (s) => s.getAll());
const dbPut = (t) => tx("readwrite", (s) => s.put(t));
const dbDel = (id) => tx("readwrite", (s) => s.delete(id));

/* ---------- state ---------- */
let templates = [], cur = null, items = [], values = {}, outBlob = null, outType = "pdf";
const uid = () => "t" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

async function init() {
  await loadPreset();
  templates = await dbAll();
  renderTpls();
  await loadItems();
  if (templates.length) select(templates[0].id);
}
async function loadPreset() {
  const { presetDone } = await browser.storage.local.get("presetDone");
  if (presetDone) return;
  try {
    const [pdf, meta] = await Promise.all([
      fetch("preset/mobilis.pdf").then((r) => r.arrayBuffer()),
      fetch("preset/mobilis.json").then((r) => r.json())
    ]);
    await dbPut({ id: "preset-mobilis", name: meta.name, type: "pdf", bytes: pdf, fields: meta.fields });
    await browser.storage.local.set({ presetDone: true });
  } catch (e) { console.error(e); }
}
async function loadItems() {
  ({ items = [] } = await browser.storage.local.get("items"));
  $("count").textContent = items.length + " collected value(s)";
}

/* ---------- templates list ---------- */
function renderTpls() {
  const box = $("tpls"); box.innerHTML = "";
  templates.forEach((t) => {
    const d = document.createElement("div");
    d.className = "tpl" + (cur && cur.id === t.id ? " sel" : "");
    d.innerHTML = `<div>${esc(t.name)}<small>${t.type.toUpperCase()}</small></div>`;
    const x = document.createElement("button"); x.className = "x"; x.textContent = "✕"; x.title = "Delete";
    x.onclick = async (e) => {
      e.stopPropagation();
      if (!confirm("Delete this template?")) return;
      await dbDel(t.id); templates = templates.filter((o) => o.id !== t.id);
      if (cur && cur.id === t.id) { cur = null; $("work").style.display = "none"; $("empty").style.display = "block"; }
      renderTpls();
    };
    d.appendChild(x); d.onclick = () => select(t.id); box.appendChild(d);
  });
}
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

$("upBtn").onclick = () => $("up").click();
$("up").onchange = async (e) => {
  for (const f of e.target.files) {
    const bytes = await f.arrayBuffer();
    const isDocx = /\.docx$/i.test(f.name);
    const t = { id: uid(), name: f.name.replace(/\.(pdf|docx)$/i, ""), type: isDocx ? "docx" : "pdf", bytes, fields: [] };
    $("empty").style.display = "none"; $("work").style.display = "block"; $("tname").textContent = t.name;
    $("autoMsg").textContent = "Analyse du formulaire… (détection automatique des champs)";
    try {
      if (isDocx) { t.tags = docxTags(bytes); t.docKeys = OCRDoc.analyze(bytes); t.detected = { count: t.docKeys.length, source: "word" }; }
      else {
        t.acro = await acroFields(bytes);
        if (!t.acro.length) { const r = await autoDetectPdf(t); t.fields = r.fields; t.detected = { count: r.fields.length, source: r.source }; }
        else t.detected = { count: t.acro.length, source: "acroform" };
      }
    } catch (err) { console.error(err); t.detected = { count: 0, source: "error", error: String(err) }; }
    await dbPut(t); templates.push(t);
  }
  e.target.value = ""; renderTpls();
  select(templates[templates.length - 1].id);
};
const PDF_OPTS = { cMapUrl: "lib/cmaps/", cMapPacked: true, standardFontDataUrl: "lib/standard_fonts/" };
async function autoDetectPdf(t) {
  const doc = await pdfjsLib.getDocument(Object.assign({ data: new Uint8Array(t.bytes.slice(0)) }, PDF_OPTS)).promise;
  const m = document.createElement("canvas").getContext("2d"); m.font = "100px Arial";
  const pages = await OCRDetect.extractPdfPages(doc, (s) => m.measureText(s).width);
  const words = pages.reduce((a, p) => a + p.tokens.filter((x) => x.type === "word").length, 0);
  if (words >= 12) return { fields: OCRDetect.pdfFields(pages), source: "text" };
  // scanned form: read the page image (words by OCR, lines / boxes from the pixels)
  const SC = 2, scans = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p), vp = page.getViewport({ scale: SC }), cv = document.createElement("canvas");
    cv.width = vp.width; cv.height = vp.height;
    const ctx = cv.getContext("2d"); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, cv.width, cv.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    const sh = OCRScan.findShapes(ctx.getImageData(0, 0, cv.width, cv.height)), ws = await OCR.words(cv);
    scans.push({
      width: vp.width / SC, height: vp.height / SC,
      words: ws.map((w) => ({ text: w.text, x0: w.x0 / SC, x1: w.x1 / SC, base: (w.y1 - (w.y1 - w.y0) * 0.2) / SC, size: (w.y1 - w.y0) / SC * 0.85 })),
      runs: sh.runs.map((r) => ({ x0: r.x0 / SC, x1: r.x1 / SC, y: r.y / SC, cellsX: r.cellsX && r.cellsX.map((c) => ({ x0: c.x0 / SC, x1: c.x1 / SC })) })),
      boxes: sh.boxes.map((b) => ({ x0: b.x0 / SC, x1: b.x1 / SC, y0: b.y0 / SC, y1: b.y1 / SC }))
    });
  }
  return { fields: OCRDetect.pdfFields(OCRDetect.scanPages(scans)), source: "scan" };
}
function docxTags(bytes) {
  const zip = new PizZip(bytes.slice(0));
  const doc = new docxtemplater(zip, { delimiters: { start: "{{", end: "}}" }, paragraphLoop: true, linebreaks: true });
  const txt = doc.getFullText(); const set = [];
  (txt.match(/\{\{\s*[^{}]+?\s*\}\}/g) || []).forEach((m) => { const k = m.slice(2, -2).trim(); if (!set.includes(k)) set.push(k); });
  return set;
}
async function acroFields(bytes) {
  try {
    const doc = await PDFLib.PDFDocument.load(bytes.slice(0));
    return doc.getForm().getFields().map((f) => ({ key: f.getName(), type: f.constructor.name === "PDFCheckBox" ? "check" : "text" }));
  } catch (e) { return []; }
}

/* ---------- select + tabs ---------- */
async function select(id) {
  cur = templates.find((t) => t.id === id);
  $("empty").style.display = "none"; $("work").style.display = "block";
  $("tname").textContent = cur.name;
  $("tabEdit").style.display = cur.type === "pdf" ? "" : "none";
  outBlob = null; $("preview").style.display = "none"; $("print").disabled = $("dl").disabled = true;
  renderTpls(); await loadItems(); buildValues(); tab("fill"); showAutoMsg();
}
function showAutoMsg() {
  const d = cur.detected, n = fieldKeys(cur).length, el = $("autoMsg");
  if (!d) { el.textContent = ""; return; }
  const src = { text: "texte du PDF", scan: "image scannée (détection partielle)", word: "document Word", acroform: "champs du PDF", error: "erreur" }[d.source] || d.source;
  el.innerHTML = n ? "✓ <b>" + n + " champ(s)</b> reconnu(s) automatiquement (" + src + "). Vérifiez les valeurs ci-dessous" + (cur.type === "pdf" ? ", et ajustez les positions dans « Edit fields » si besoin." : ".")
    : "Aucun champ reconnu automatiquement" + (cur.type === "pdf" ? " : ouvrez « Edit fields » pour placer les champs à la main." : " : écrivez par ex. « Nom : ………… » ou {{nom}} dans le Word.");
}
// collected values changed in another tab/popup -> refresh without losing manual edits
browser.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.items && cur) { items = ch.items.newValue || []; $("count").textContent = items.length + " collected value(s)"; buildValues(true); renderGrid(); } });
function tab(n) {
  $("fill").style.display = n === "fill" ? "block" : "none";
  $("edit").style.display = n === "edit" ? "block" : "none";
  $("tabFill").className = n === "fill" ? "on" : ""; $("tabEdit").className = n === "edit" ? "on" : "";
  if (n === "edit") startEditor(); else renderGrid();
}
$("tabFill").onclick = () => tab("fill"); $("tabEdit").onclick = () => tab("edit");
$("reload").onclick = async () => { await loadItems(); buildValues(true); renderGrid(); };

/* ---------- field list for the template ---------- */
function fieldKeys(t) {
  const out = [], seen = {};
  const add = (key, kind, opt) => {
    if (!seen[key]) { seen[key] = { key, kind, options: [] }; out.push(seen[key]); }
    if (kind === "select") { seen[key].kind = "select"; if (opt != null && !seen[key].options.includes(opt)) seen[key].options.push(opt); }
  };
  (t.acro || []).forEach((a) => a.type === "check" ? add(a.key, "select", "Yes") : add(a.key, "text"));
  (t.fields || []).forEach((f) => f.type === "check" ? add(f.key, "select", f.match) : add(f.key, "text"));
  (t.docKeys || []).forEach((k) => k.kind === "select" ? k.options.forEach((o) => add(k.key, "select", o)) : add(k.key, "text"));
  (t.tags || []).forEach((k) => add(k, "text"));
  return out;
}

/* ---------- auto matching ---------- */
function buildValues(keepManual) { values = OCRFill.autoMatch(fieldKeys(cur), items, keepManual ? values : {}); }

/* ---------- fill UI ---------- */
function renderGrid() {
  const g = $("grid"); g.innerHTML = "";
  ["Field", "Value", "Pick from collected"].forEach((h) => { const d = document.createElement("div"); d.className = "h"; d.textContent = h; g.appendChild(d); });
  const keys = fieldKeys(cur);
  if (!keys.length) {
    g.innerHTML = cur.type === "docx"
      ? '<div class="hint" style="grid-column:1/-1">No {{placeholders}} found in this Word file. Add e.g. {{name}} in the document and upload it again.</div>'
      : '<div class="hint" style="grid-column:1/-1">No fields yet. Open "Edit fields" and draw boxes where values must go.</div>';
    return;
  }
  keys.forEach((k) => {
    const l = document.createElement("div"); l.textContent = k.key; g.appendChild(l);
    let inp;
    if (k.kind === "select") {
      inp = document.createElement("select");
      inp.innerHTML = '<option value="">—</option>' + k.options.map((o) => `<option>${esc(o)}</option>`).join("");
      inp.value = values[k.key] || "";
      if (inp.value !== (values[k.key] || "")) inp.value = "";
    } else { inp = document.createElement("input"); inp.value = values[k.key] || ""; }
    inp.oninput = inp.onchange = () => { values[k.key] = inp.value; };
    g.appendChild(inp);
    const pick = document.createElement("select");
    pick.innerHTML = '<option value="">choose…</option>' + items.map((it, i) => `<option value="${i}">${esc(it.label)}: ${esc(it.text.slice(0, 40))}</option>`).join("");
    pick.onchange = () => {
      if (pick.value === "") return;
      const t = items[+pick.value].text;
      if (k.kind === "select") { const o = k.options.find((x) => norm(x) === norm(t)); inp.value = o || ""; values[k.key] = inp.value; }
      else { inp.value = t; values[k.key] = t; }
      pick.value = "";
    };
    g.appendChild(pick);
  });
}

/* ---------- generate / print ---------- */
$("gen").onclick = async () => {
  try {
    if (cur.type === "pdf") {
      const out = await fillPdf(PDFLib, cur.bytes.slice(0), cur.fields, values);
      outBlob = new Blob([out], { type: "application/pdf" }); outType = "pdf";
      const url = URL.createObjectURL(outBlob);
      $("preview").src = url; $("preview").style.display = "block";
    } else {
      let zip = new PizZip(cur.bytes.slice(0));
      if (cur.tags && cur.tags.length) {
        const doc = new docxtemplater(zip, { delimiters: { start: "{{", end: "}}" }, paragraphLoop: true, linebreaks: true, nullGetter: () => "" });
        doc.render(values); zip = doc.getZip();
      }
      const filled = OCRDoc.fill(zip.generate({ type: "uint8array" }), values);
      outBlob = filled.generate({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
      outType = "docx"; $("preview").style.display = "none";
    }
    $("print").disabled = $("dl").disabled = false;
  } catch (e) { alert("Could not generate: " + e.message); }
};
$("dl").onclick = () => {
  const a = document.createElement("a"); a.href = URL.createObjectURL(outBlob);
  a.download = cur.name + " - filled." + outType; a.click();
};
$("print").onclick = async () => {
  if (outType === "pdf") { window.open(URL.createObjectURL(outBlob), "_blank"); return; }
  const c = $("docPrint"); c.innerHTML = "";
  await docx.renderAsync(outBlob, c);
  document.body.classList.add("printing");
  setTimeout(() => { window.print(); document.body.classList.remove("printing"); }, 300);
};

/* ---------- field editor (PDF) ---------- */
let pdfDoc = null, pageNo = 0, scale = 1.4, selId = null, drag = null;
async function startEditor() {
  $("saved").textContent = "";
  pdfDoc = await pdfjsLib.getDocument(Object.assign({ data: new Uint8Array(cur.bytes.slice(0)) }, PDF_OPTS)).promise;
  pageNo = 0; await drawPage(); renderPanel();
}
async function drawPage() {
  const page = await pdfDoc.getPage(pageNo + 1);
  const vp = page.getViewport({ scale });
  const cv = $("cv"); cv.width = vp.width; cv.height = vp.height;
  await page.render({ canvasContext: cv.getContext("2d"), viewport: vp }).promise;
  $("stage").style.width = vp.width + "px"; $("stage").style.height = vp.height + "px";
  $("pgNav").innerHTML = pdfDoc.numPages > 1
    ? `<button id="pp">◀</button> Page ${pageNo + 1}/${pdfDoc.numPages} <button id="pn">▶</button>` : "";
  if ($("pp")) { $("pp").onclick = async () => { if (pageNo > 0) { pageNo--; await drawPage(); } }; $("pn").onclick = async () => { if (pageNo < pdfDoc.numPages - 1) { pageNo++; await drawPage(); } }; }
  renderBoxes();
}
function renderBoxes() {
  const ov = $("ov"); ov.innerHTML = "";
  cur.fields.filter((f) => (f.page || 0) === pageNo).forEach((f) => {
    const b = document.createElement("div");
    b.className = "box" + (f.type === "check" ? " check" : "") + (f.id === selId ? " sel" : "");
    Object.assign(b.style, { left: f.x * scale + "px", top: f.y * scale + "px", width: f.w * scale + "px", height: f.h * scale + "px" });
    b.textContent = f.key + (f.match ? " = " + f.match : "");
    b.onmousedown = (e) => { e.stopPropagation(); selId = f.id; renderBoxes(); renderPanel(); };
    ov.appendChild(b);
  });
  document.getElementById("keys").innerHTML = [...new Set(cur.fields.map((f) => f.key))].map((k) => `<option value="${esc(k)}">`).join("");
}
$("ov").addEventListener("mousedown", (e) => {
  if (e.target !== $("ov")) return;
  const r = $("ov").getBoundingClientRect();
  drag = { x0: e.clientX - r.left, y0: e.clientY - r.top, el: document.createElement("div") };
  drag.el.className = "box"; $("ov").appendChild(drag.el);
});
window.addEventListener("mousemove", (e) => {
  if (!drag) return;
  const r = $("ov").getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
  Object.assign(drag.el.style, { left: Math.min(x, drag.x0) + "px", top: Math.min(y, drag.y0) + "px", width: Math.abs(x - drag.x0) + "px", height: Math.abs(y - drag.y0) + "px" });
});
window.addEventListener("mouseup", (e) => {
  if (!drag) return;
  const r = $("ov").getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
  const w = Math.abs(x - drag.x0), h = Math.abs(y - drag.y0);
  drag.el.remove();
  if (w > 4 && h > 4) {
    const f = { id: uid(), key: "Field " + (cur.fields.length + 1), type: "text", page: pageNo, x: Math.min(x, drag.x0) / scale, y: Math.min(y, drag.y0) / scale, w: w / scale, h: h / scale, size: 10 };
    cur.fields.push(f); selId = f.id;
  }
  drag = null; renderBoxes(); renderPanel();
});
function renderPanel() {
  const p = $("panel"); const f = cur.fields.find((x) => x.id === selId);
  if (!f) { p.innerHTML = '<p class="hint">Draw a box, or click an existing one to edit it.</p>'; return; }
  p.innerHTML = `
    <label>Field name (shared by a checkbox group)</label><input id="f_key" list="keys" value="${esc(f.key)}">
    <label>Type</label><select id="f_type"><option value="text">Text</option><option value="check">Checkbox (draws X)</option><option value="cells">Digits in cells (phone…)</option></select>
    <div id="f_check"><label>Value when checked</label><input id="f_match" value="${esc(f.match || "")}"></div>
    <div id="f_text"><label>Font size</label><input id="f_size" type="number" value="${f.size || 10}">
    <label>Date part (for date boxes split in day / month / year)</label>
    <select id="f_part"><option value="">whole value</option><option value="day">day</option><option value="month">month</option><option value="year">year</option></select></div>
    <div id="f_cells"><label>Number of cells</label><input id="f_n" type="number" value="${f.cells || 5}"><label>Characters per cell</label><input id="f_ch" type="number" value="${f.chunk || 2}"></div>
    <label>Only if field… (optional)</label><input id="f_wk" placeholder="field name" value="${esc(f.whenKey || "")}"><input id="f_wv" placeholder="equals value" value="${esc(f.whenVal || "")}" style="margin-top:4px">
    <div class="bar"><button class="r" id="f_del">Delete box</button></div>`;
  $("f_type").value = f.type; $("f_part").value = f.part || "";
  const vis = () => { $("f_check").style.display = f.type === "check" ? "" : "none"; $("f_text").style.display = f.type === "check" ? "none" : ""; $("f_cells").style.display = f.type === "cells" ? "" : "none"; };
  vis();
  const bind = (id, fn) => { $(id).oninput = $(id).onchange = () => { fn($(id).value); renderBoxes(); }; };
  bind("f_key", (v) => (f.key = v)); bind("f_match", (v) => (f.match = v)); bind("f_size", (v) => (f.size = +v || 10));
  bind("f_part", (v) => (f.part = v || undefined)); bind("f_n", (v) => (f.cells = +v || 5)); bind("f_ch", (v) => (f.chunk = +v || 2));
  bind("f_wk", (v) => (f.whenKey = v || undefined)); bind("f_wv", (v) => (f.whenVal = v || undefined));
  $("f_type").onchange = () => { f.type = $("f_type").value; vis(); renderBoxes(); };
  $("f_del").onclick = () => { cur.fields = cur.fields.filter((x) => x.id !== f.id); selId = null; renderBoxes(); renderPanel(); };
}
$("redetect").onclick = async () => {
  if (cur.fields.length && !confirm("Replace the current boxes by a new automatic detection?")) return;
  $("saved").textContent = "Analyse…";
  const r = await autoDetectPdf(cur); cur.fields = r.fields; cur.detected = { count: r.fields.length, source: r.source };
  selId = null; await dbPut(cur); renderBoxes(); renderPanel(); $("saved").textContent = r.fields.length + " champs détectés ✓";
};
$("save").onclick = async () => { await dbPut(cur); $("saved").textContent = "Saved ✓"; };

init();
