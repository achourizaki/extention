// Shared OCR settings (used by offscreen.js and by the test agent)
(function (root) {
  const cfg = {
    scale: 2,        // upscale factor of the cropped screenshot
    pad: 16,         // padding (px, after upscale) around the crop
    smallPx: 80,     // crops shorter than this (px, before upscale) = one text line
    bigPx: 1500000,  // crops larger than this (px², before upscale) are not upscaled
    psmSmall: 7,     // single text line
    psmLarge: 6,     // uniform block (a card / a form)
    psmPage: 3       // whole page, automatic layout
  };
  cfg.scaleFor = (w, h) => (w * h > cfg.bigPx ? 1 : cfg.scale);
  cfg.psm = (w, h) => String(h < cfg.smallPx ? cfg.psmSmall : w * h > cfg.bigPx ? cfg.psmPage : cfg.psmLarge);
  root.OCR_CONFIG = cfg;
  if (typeof module !== "undefined") module.exports = cfg;
})(typeof window !== "undefined" ? window : globalThis);
