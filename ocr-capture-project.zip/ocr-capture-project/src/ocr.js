// OCR engine shared by every build:
//  - Chrome MV3: runs inside offscreen.html     - Chrome legacy / Firefox: runs inside the background page
(function (root) {
  let workerPromise;
  const url = (p) => browser.runtime.getURL(p);
  function getWorker() {
    if (!workerPromise) {
      workerPromise = Tesseract.createWorker("eng", 1, {
        workerPath: url("lib/worker.min.js"), corePath: url("lib/"), langPath: url("lang/"), workerBlobURL: false
      });
      workerPromise.catch(() => { workerPromise = null; });
    }
    return workerPromise;
  }
  function loadImage(src) {
    return new Promise((res, rej) => { const img = new Image(); img.onload = () => res(img); img.onerror = rej; img.src = src; });
  }
  // grayscale, auto-invert dark backgrounds, stretch contrast, pad the edges
  function prepare(cv) {
    const p = OCR_CONFIG.pad, o = document.createElement("canvas");
    o.width = cv.width + p * 2; o.height = cv.height + p * 2;
    const src = cv.getContext("2d").getImageData(0, 0, cv.width, cv.height), d = src.data;
    let sum = 0;
    for (let i = 0; i < d.length; i += 4) { const y = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; d[i] = d[i + 1] = d[i + 2] = y; sum += y; }
    const invert = sum / (d.length / 4) < 128;
    let lo = 255, hi = 0;
    for (let i = 0; i < d.length; i += 4) { if (invert) d[i] = 255 - d[i]; lo = Math.min(lo, d[i]); hi = Math.max(hi, d[i]); }
    const k = hi > lo ? 255 / (hi - lo) : 1;
    for (let i = 0; i < d.length; i += 4) { const v = Math.max(0, Math.min(255, (d[i] - lo) * k)); d[i] = d[i + 1] = d[i + 2] = v; }
    const g = o.getContext("2d"), bg = d[0];
    g.fillStyle = "rgb(" + bg + "," + bg + "," + bg + ")"; g.fillRect(0, 0, o.width, o.height); g.putImageData(src, p, p);
    return o;
  }
  async function run(msg) {
    try {
      const img = await loadImage(msg.dataUrl);
      const d = msg.dpr || 1, scale = OCR_CONFIG.scaleFor(msg.rect.w * d, msg.rect.h * d);
      const c = document.createElement("canvas");
      c.width = Math.round(msg.rect.w * d * scale); c.height = Math.round(msg.rect.h * d * scale);
      const ctx = c.getContext("2d");
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(img, msg.rect.x * d, msg.rect.y * d, msg.rect.w * d, msg.rect.h * d, 0, 0, c.width, c.height);
      const worker = await getWorker();
      await worker.setParameters({ tessedit_pageseg_mode: OCR_CONFIG.psm(msg.rect.w * d, msg.rect.h * d) });
      const { data } = await worker.recognize(prepare(c));
      return { text: data.text };
    } catch (e) { return { text: "", error: String(e) }; }
  }
  async function words(canvas) {     // every word of a rendered page with its box (pixels)
    const worker = await getWorker();
    await worker.setParameters({ tessedit_pageseg_mode: "3" });
    const { data } = await worker.recognize(canvas);
    return data.words.map((w) => ({ text: w.text, x0: w.bbox.x0, y0: w.bbox.y0, x1: w.bbox.x1, y1: w.bbox.y1 }));
  }
  root.OCR = { run, words };
})(self);
