// Chrome MV3 only: the service worker has no DOM, so OCR runs here.
browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== "offscreen" || msg.type !== "ocr") return;
  OCR.run(msg).then(sendResponse);
  return true;
});
