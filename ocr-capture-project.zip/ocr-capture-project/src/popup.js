const $ = (id) => document.getElementById(id);
let items = [];
$("cats").innerHTML = OCRClassify.CATS.map((c) => `<option value="${c}">`).join("");

async function load() { ({ items = [] } = await browser.storage.local.get("items")); render(); }
async function save() {
  await browser.storage.local.set({ items });
  (browser.action || browser.browserAction).setBadgeText({ text: items.length ? String(items.length) : "" });
}
function render() {
  const list = $("list"); list.innerHTML = "";
  if (!items.length) list.innerHTML = "<small>Aucune valeur pour l’instant.</small>";
  const order = OCRClassify.CATS;
  items.slice().sort((a, b) => order.indexOf(a.label) - order.indexOf(b.label)).forEach((it) => {
    const div = document.createElement("div"); div.className = "item" + (it.uncertain ? " unc" : "");
    const del = document.createElement("button"); del.className = "del"; del.textContent = "✕";
    del.onclick = async () => { items = items.filter((x) => x !== it); await save(); render(); };
    const label = document.createElement("input"); label.setAttribute("list", "cats"); label.value = it.label;
    label.onchange = () => { it.label = label.value; it.uncertain = false; save(); render(); };
    const text = document.createElement("textarea"); text.value = it.text;
    text.oninput = () => { it.text = text.value; save(); };
    div.append(del, label, text);
    if (it.uncertain) { const w = document.createElement("small"); w.className = "warn"; w.textContent = "⚠ catégorie incertaine : vérifiez-la"; div.appendChild(w); }
    list.appendChild(div);
  });
}
$("select").onclick = () => { browser.runtime.sendMessage({ type: "start", mode: "select" }); window.close(); };
$("page").onclick = () => { browser.runtime.sendMessage({ type: "start", mode: "page" }); window.close(); };
$("forms").onclick = () => { browser.tabs.create({ url: browser.runtime.getURL("forms.html") }); window.close(); };
$("clear").onclick = async () => { items = []; await save(); render(); };
load();
