// Scanned forms: finds dotted/underlined lines, "|__|__|" cells and small square checkboxes in the page IMAGE.
// Input: {data (RGBA), width, height}.  Output in pixels.
(function (root) {
  function findShapes(img) {
    const W = img.width, H = img.height, d = img.data, dark = new Uint8Array(W * H), soft = new Uint8Array(W * H);
    for (let i = 0, j = 0; j < dark.length; i += 4, j++) { const g = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; dark[j] = g < 185 ? 1 : 0; soft[j] = g < 215 ? 1 : 0; }
    const MINSOLID = Math.max(10, Math.round(W / 75)), MINDOT = Math.round(W / 22), G = Math.max(3, Math.round(W / 240)), MAXH = Math.max(4, Math.round(W / 200));
    const comps = (mode) => {
      const done = [], open = [];
      let prev = [];
      for (let y = 0; y < H; y++) {
        const row = y * W, runs = [];
        let pre = null, x = 0;
        if (mode === "dot") {                       // horizontal closing so dots merge into a line
          pre = new Int32Array(W + 1); for (let i = 0; i < W; i++) pre[i + 1] = pre[i] + dark[row + i];
        }
        let start = -1;
        for (x = 0; x <= W; x++) {
          const on = x < W && (mode === "solid" ? dark[row + x] === 1 : (pre[Math.min(W, x + G + 1)] - pre[Math.max(0, x - G)]) > 0);
          if (on && start < 0) start = x;
          if (!on && start >= 0) { if (x - start >= (mode === "solid" ? MINSOLID : MINDOT)) runs.push([start, x]); start = -1; }
        }
        const cur = [];
        runs.forEach((r) => {
          let hit = prev.find((c) => c.y1 === y - 1 && Math.min(c.x1, r[1]) - Math.max(c.x0, r[0]) > 0.5 * Math.min(c.x1 - c.x0, r[1] - r[0]));
          if (hit) { hit.y1 = y; hit.x0 = Math.min(hit.x0, r[0]); hit.x1 = Math.max(hit.x1, r[1]); cur.push(hit); }
          else { const c = { x0: r[0], x1: r[1], y0: y, y1: y }; open.push(c); cur.push(c); }
        });
        prev = cur;
      }
      return open.filter((c) => c.y1 - c.y0 + 1 <= MAXH);
    };
    const solid = comps("solid"), dotted = comps("dot");
    const overlap = (a, b) => Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0) > 0.5 * Math.min(a.x1 - a.x0, b.x1 - b.x0) && Math.abs((a.y0 + a.y1) / 2 - (b.y0 + b.y1) / 2) <= MAXH;
    const dots = dotted.filter((c) => !solid.some((s) => overlap(c, s)));
    // group solid segments that sit on the same line with small gaps -> cells  "|__|__|__|"
    const runs = [], used = new Set();
    const ss = solid.slice().sort((a, b) => (a.y1 - b.y1) || (a.x0 - b.x0));
    ss.forEach((s) => {
      if (used.has(s)) return;
      const grp = [s]; used.add(s);
      let last = s;
      ss.forEach((t) => { if (!used.has(t) && Math.abs(t.y1 - s.y1) <= 2 && t.x0 - last.x1 >= 0 && t.x0 - last.x1 <= Math.max(18, (last.x1 - last.x0) * 0.8) && Math.abs((t.x1 - t.x0) - (s.x1 - s.x0)) <= (s.x1 - s.x0) * 0.4) { grp.push(t); used.add(t); last = t; } });
      if (grp.length >= 2) runs.push({ x0: grp[0].x0, x1: grp[grp.length - 1].x1, y: s.y1, cellsX: grp.map((g) => ({ x0: g.x0, x1: g.x1 })) });
      else if (s.x1 - s.x0 >= MINDOT) {
        // a long thin line crossed by short vertical bars "|____|____|" -> cells
        const up = Math.max(5, Math.round(W / 200)), bars = [];
        for (let x = s.x0; x <= s.x1; x++) {
          let n = 0; for (let k = 3; k <= up + 3; k++) if (s.y0 - k >= 0 && dark[(s.y0 - k) * W + x]) n++;
          if (n >= up - 1) { const last = bars[bars.length - 1]; if (last && x - last.b <= 2) last.b = x; else bars.push({ a: x, b: x }); }
        }
        if (bars.length >= 3) {
          const cx = []; for (let i = 0; i + 1 < bars.length; i++) if (bars[i + 1].a - bars[i].b > 6) cx.push({ x0: bars[i].b + 1, x1: bars[i + 1].a - 1 });
          if (cx.length >= 3) { runs.push({ x0: cx[0].x0, x1: cx[cx.length - 1].x1, y: s.y1, cellsX: cx }); return; }
        }
        runs.push({ x0: s.x0, x1: s.x1, y: s.y1 });
      }
    });
    dots.forEach((c) => runs.push({ x0: c.x0, x1: c.x1, y: c.y1 }));
    // square checkboxes: small hollow components with dark corners
    const seen = new Uint8Array(W * H), boxes = [], stack = [];
    for (let p = 0; p < dark.length; p++) {
      if (!soft[p] || seen[p]) continue;
      let minx = W, maxx = 0, miny = H, maxy = 0, cnt = 0; stack.length = 0; stack.push(p); seen[p] = 1; let big = false;
      while (stack.length) {
        const q = stack.pop(), x = q % W, y = (q - x) / W; cnt++;
        if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y;
        if (maxx - minx > 40 || maxy - miny > 40) big = true;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
          const n = ny * W + nx; if (soft[n] && !seen[n]) { seen[n] = 1; stack.push(n); }
        }
      }
      if (big) continue;
      const w = maxx - minx + 1, h = maxy - miny + 1, mn = Math.round(W / 220), mx = Math.round(W / 40);
      if (w < mn || h < mn || w > mx || h > mx || Math.abs(w - h) > Math.max(3, w * 0.25) || cnt / (w * h) > 0.5) continue;
      // a real checkbox: all four edges are (almost) fully dark and the inside is empty
      const frac = (xa, ya, xb, yb) => { let n = 0, t = 0; for (let y = ya; y <= yb; y++) for (let x = xa; x <= xb; x++) { t++; if (soft[y * W + x]) n++; } return t ? n / t : 0; };
      const e = Math.max(1, Math.round(Math.min(w, h) * 0.15)), c = Math.round(Math.min(w, h) * 0.3);
      const top = frac(minx + c, miny, maxx - c, miny), bot = frac(minx + c, maxy, maxx - c, maxy), lef = frac(minx, miny + c, minx, maxy - c), rig = frac(maxx, miny + c, maxx, maxy - c);
      const inside = frac(minx + e + 1, miny + e + 1, maxx - e - 1, maxy - e - 1);
      if (top > 0.85 && bot > 0.85 && lef > 0.85 && rig > 0.85 && inside < 0.12) boxes.push({ x0: minx, y0: miny, x1: maxx + 1, y1: maxy + 1 });
    }
    return { runs, boxes };
  }
  root.OCRScan = { findShapes };
  if (typeof module !== "undefined") module.exports = root.OCRScan;
})(typeof window !== "undefined" ? window : globalThis);
