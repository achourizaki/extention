#!/usr/bin/env node
/*
  TEST AGENT for "OCR Capture & Form Filler"
  1. generates fake profiles (names/places both inside AND outside the classifier dictionary)
  2. draws values as "screenshots" (random font / size / colours / tight crops)
  3. reads them with the SAME OCR settings as the extension
  4. TEST A  value by value : classify.js must put each value in the right category
     TEST B  a whole profile card in ONE screenshot : every category found at once
  5. fills the Mobilis PDF with the values collected in test A (extension's own matching + fill code)
  6. checks the PDF really contains the values (text + checkbox marks)
  Output: ./out/report.html, ./out/results.json, ./out/profile-N.pdf
  Usage:  node agent.js [--count 20] [--seed 1] [--keep-images]
*/
const fs = require("fs"), path = require("path");
const { createCanvas } = require("@napi-rs/canvas");
const Tesseract = require("tesseract.js");
const PDFLib = require("pdf-lib");

const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, r) => x.startsWith("--") ? [...a, [x.slice(2), r[i + 1] && !r[i + 1].startsWith("--") ? r[i + 1] : true]] : a, []));
const COUNT = +args.count || 10, SEED = +args.seed || 1;
const EXT = process.env.EXT_DIR || path.join(__dirname, "../../dist/ocr-capture-chrome");   // run "npm run build" first
const LANG = path.join(EXT, "lang");
const OCRFill = require(path.join(EXT, "fill.js")), Classify = require(path.join(EXT, "classify.js")), OCR_CONFIG = require(path.join(EXT, "ocr-config.js"));
const { norm } = OCRFill;
const OUT = path.join(__dirname, "out"); fs.mkdirSync(OUT, { recursive: true });
const tpl = JSON.parse(fs.readFileSync(path.join(EXT, "preset/mobilis.json")));
const pdfBytes = fs.readFileSync(path.join(EXT, "preset/mobilis.pdf"));

/* ---------- profile generator ---------- */
function rng(seed) { return () => { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const R = rng(SEED), pick = (a) => a[Math.floor(R() * a.length)], int = (a, b) => a + Math.floor(R() * (b - a + 1)), p2 = (n) => String(n).padStart(2, "0");
const LAST = ["Benali", "Boudiaf", "Messaoudi", "Haddad", "Cherif", "Bouzid", "Khelifi", "Mansouri", "Belkacem", "Saidi", "Ferhat", "Lounis", "Brahimi",   // in dictionary
  "Zaki", "Hadjadj", "Boulahia", "Rezgui", "Kherbache", "Aouimeur", "Mokrani", "Chabane", "Toumi", "Bellil"];                                            // NOT in dictionary
const FIRST_M = ["Mohamed", "Ahmed", "Yacine", "Amine", "Karim", "Walid", "Riad", "Sofiane", "Abdelkader", "Anouar", "Rafik", "Taha", "Sidali", "Nassim"],
  FIRST_F = ["Amel", "Sarah", "Lamia", "Nadia", "Meriem", "Fatima", "Imene", "Samira", "Dounia", "Lilia", "Hadjer", "Yousra", "Cylia", "Tinhinane"];
const PLACES = ["Blida", "Alger", "Oran", "Setif", "Annaba", "Batna", "Tizi Ouzou", "Constantine", "Bejaia", "Medea",    // in dictionary
  "Khemis Miliana", "Berrouaghia", "Sidi Aissa", "Bordj Menaiel", "Ain Benian", "Reghaia", "Tablat"];                    // NOT in dictionary
const OFFERS = [["SAMA", null], ["SAMA CONTROL", [1300, 1500, 2000, 3500]], ["SAMA LIBRE", [1300, 1500, 2000, 3500]], ["TWENTY", null], ["TWENTY PREMIUM", null], ["WIN MAX CONTROL", [650, 1000, 1500]], ["WIN MAX LIBRE", [650, 1000, 1500]]];
const PHONE_FMT = [(s) => s, (s) => s.replace(/(\d{4})(\d{2})(\d{2})(\d{2})/, "$1 $2 $3 $4"), (s) => s.replace(/(\d{2})(?=\d)/g, "$1 ").trim()];
function genProfile() {
  const civ = pick(["Monsieur", "Madame", "Melle"]), offer = pick(OFFERS);
  const caps = R() < 0.3;   // sometimes the surname is written in capitals (common on ID documents)
  const nom = pick(LAST);
  return {
    "Civilité": civ, "Nom": caps ? nom.toUpperCase() : nom, "Prénom": pick(civ === "Monsieur" ? FIRST_M : FIRST_F),
    "Date de naissance": `${p2(int(1, 28))}/${p2(int(1, 12))}/${int(1960, 2005)}`, "Lieu de naissance": pick(PLACES),
    "Téléphone": "06" + pick(["5", "6", "7"]) + String(int(0, 9999999)).padStart(7, "0"),
    "N° de contact": pick(["05", "07"]) + String(int(0, 99999999)).padStart(8, "0"),
    "Pièce": pick(["CIN", "PASSEPORT"]), "N° pièce": String(int(100000000, 999999999)),
    "Date de délivrance": `${p2(int(1, 28))}/${p2(int(1, 12))}/${int(2015, 2025)}`, "Délivrée à": pick(PLACES),
    "Offre": offer[0], "Montant": offer[1] ? String(pick(offer[1])) : "", "Date": OCRFill.today()
  };
}
const ORDER = ["Civilité", "Nom", "Prénom", "Date de naissance", "Lieu de naissance", "Téléphone", "N° de contact", "Pièce", "N° pièce", "Date de délivrance", "Délivrée à", "Offre"];
const expectedSingle = (p, k, phones) => k === "Téléphone" ? phones[0] : k === "N° de contact" ? phones[1] : k === "Offre" ? p["Offre"] + (p["Montant"] ? ` ${p["Montant"]} DA` : "") : p[k];

/* ---------- drawing ---------- */
const FONTS = ["Arial", "Verdana", "Georgia", "Tahoma", "DejaVu Sans", "Liberation Sans", "Segoe UI"];
const THEMES = [["#ffffff", "#111111"], ["#f3f4f6", "#1f2937"], ["#fffbe6", "#222222"], ["#1e293b", "#e2e8f0"], ["#e8f0fe", "#0b3d91"]];
function drawSnippet(text) {
  const size = int(15, 26), font = `${pick(["", "bold "])}${size}px ${pick(FONTS)}`, [bg, fg] = pick(THEMES);
  const m = createCanvas(10, 10).getContext("2d"); m.font = font;
  const px = int(1, 6), py = int(1, 5), w = Math.ceil(m.measureText(text).width) + px * 2, h = size + py * 2 + 2;
  const c = createCanvas(w, h), x = c.getContext("2d");
  x.fillStyle = bg; x.fillRect(0, 0, w, h); x.fillStyle = fg; x.font = font; x.textBaseline = "middle"; x.fillText(text, px, h / 2 + 1);
  return c;
}
function drawCard(p, phones) {
  const size = int(14, 19), font = pick(FONTS), [bg, fg] = pick(THEMES), W = 440, rh = Math.round(size * 1.7), pad = 18;
  const rows = [["Nom", p["Nom"]], ["Prénom", p["Prénom"]], ["Date de naissance", p["Date de naissance"]], ["Lieu de naissance", p["Lieu de naissance"]],
    ["Téléphone", phones[0]], ["N° de contact", phones[1]], ["Pièce", p["Pièce"]], ["N° de la pièce", p["N° pièce"]],
    ["Délivrée le", p["Date de délivrance"]], ["Délivrée à", p["Délivrée à"]], ["Offre", p["Offre"] + (p["Montant"] ? ` — ${p["Montant"]} DA` : "")]];
  const H = pad * 2 + Math.round(size * 3.4) + rows.length * rh, c = createCanvas(W, H), x = c.getContext("2d");
  x.fillStyle = bg; x.fillRect(0, 0, W, H); x.fillStyle = fg; x.textBaseline = "top";
  x.globalAlpha = 0.7; x.font = `${Math.round(size * 0.85)}px ${font}`; x.fillText(p["Civilité"], pad, pad); x.globalAlpha = 1;
  x.font = `${Math.round(size * 1.3)}px ${font}`; x.fillText(`${p["Nom"]} ${p["Prénom"]}`, pad, pad + size * 1.3);
  rows.forEach(([l, v], i) => { const y = pad + size * 3.4 + i * rh; x.font = `${size}px ${font}`; x.globalAlpha = 0.65; x.fillText(l, pad, y); x.globalAlpha = 1; x.fillText(v, pad + 190, y); });
  return c;
}
// same as offscreen.js: upscale (x2, or x1 for big crops), grayscale, auto-invert, contrast, padding
function prepare(cv) {
  const p = OCR_CONFIG.pad, o = createCanvas(cv.width + p * 2, cv.height + p * 2), g = o.getContext("2d");
  const src = cv.getContext("2d").getImageData(0, 0, cv.width, cv.height), d = src.data; let sum = 0;
  for (let i = 0; i < d.length; i += 4) { const y = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; d[i] = d[i + 1] = d[i + 2] = y; sum += y; }
  const invert = sum / (d.length / 4) < 128; let lo = 255, hi = 0;
  for (let i = 0; i < d.length; i += 4) { if (invert) d[i] = 255 - d[i]; lo = Math.min(lo, d[i]); hi = Math.max(hi, d[i]); }
  const k = hi > lo ? 255 / (hi - lo) : 1;
  for (let i = 0; i < d.length; i += 4) { const v = Math.max(0, Math.min(255, (d[i] - lo) * k)); d[i] = d[i + 1] = d[i + 2] = v; }
  const bg = d[0]; g.fillStyle = `rgb(${bg},${bg},${bg})`; g.fillRect(0, 0, o.width, o.height); g.putImageData(src, p, p); return o;
}
async function ocr(worker, c, name) {
  const k = OCR_CONFIG.scaleFor(c.width, c.height), up = createCanvas(c.width * k, c.height * k), u = up.getContext("2d");
  u.imageSmoothingQuality = "high"; u.drawImage(c, 0, 0, up.width, up.height);
  const img = prepare(up).toBuffer("image/png");
  if (args["keep-images"]) fs.writeFileSync(path.join(OUT, name + ".png"), img);
  await worker.setParameters({ tessedit_pageseg_mode: OCR_CONFIG.psm(c.width, c.height) });
  return (await worker.recognize(img)).data.text;
}

/* ---------- helpers ---------- */
const digits = (s) => String(s).replace(/\D/g, "");
const same = (cat, a, b) => /Date|Téléphone|contact|N° pièce|Montant/.test(cat) ? digits(a) === digits(b) : norm(a) === norm(b);
async function readPdf(bytes) {
  const pdfjs = require("pdfjs-dist/legacy/build/pdf.js");
  const doc = await pdfjs.getDocument({ data: new Uint8Array(bytes), verbosity: 0 }).promise, page = await doc.getPage(1);
  const text = (await page.getTextContent()).items.map((i) => i.str.trim()).filter(Boolean);
  return { text, paths: (await page.getOperatorList()).fnArray.filter((f) => f === pdfjs.OPS.constructPath).length };
}
const stat = (o, k, ok) => { (o[k] = o[k] || { ok: 0, n: 0 }); o[k].n++; o[k].ok += ok ? 1 : 0; };
const merge = (items, found) => found.forEach((f) => { const i = f.label === "Texte" ? -1 : items.findIndex((x) => x.label === f.label); const it = { id: f.label + items.length, label: f.label, text: f.text, uncertain: f.uncertain }; if (i >= 0) items[i] = it; else items.push(it); });

/* ---------- main ---------- */
(async () => {
  console.log(`Extension code: ${EXT}\nProfiles: ${COUNT}, seed ${SEED}\n`);
  const worker = await Tesseract.createWorker("eng", 1, { langPath: LANG, gzip: true, cacheMethod: "none", logger: () => {} });
  const blank = await readPdf(pdfBytes), results = [], A = {}, B = {}, finalStat = {}; let uncertainTotal = 0, uncertainWrong = 0;
  for (let n = 1; n <= COUNT; n++) {
    const prof = genProfile(), phones = [pick(PHONE_FMT)(prof["Téléphone"]), pick(PHONE_FMT)(prof["N° de contact"])];
    const rowsA = [], items = [];
    /* TEST A: value by value, in natural order, existing labels = what is already collected */
    for (const key of ORDER) {
      const truth = expectedSingle(prof, key, phones);
      const text = await ocr(worker, drawSnippet(truth), `p${n}-${norm(key)}`);
      const found = Classify.extract(text, items.map((i) => i.label));
      const hit = found.find((f) => f.label === key);
      const wanted = key === "Offre" ? prof["Offre"] : key === "Téléphone" ? prof["Téléphone"] : key === "N° de contact" ? prof["N° de contact"] : prof[key];
      const ok = !!hit && same(key, hit.text, wanted);
      stat(A, key, ok);
      found.forEach((f) => { if (f.uncertain) { uncertainTotal++; if (!(f.label === key && ok)) uncertainWrong++; } });
      rowsA.push({ key, truth, ocr: text.replace(/\s+/g, " ").trim(), got: found.map((f) => `${f.label}=${f.text}${f.uncertain ? "?" : ""}`).join(" | "), ok });
      merge(items, found);
    }
    /* TEST B: whole card in one screenshot */
    const cardText = await ocr(worker, drawCard(prof, phones), `p${n}-card`);
    const foundB = Classify.extract(cardText, []), rowsB = [];
    for (const key of [...ORDER.filter((k) => k !== "Offre"), "Offre", ...(prof["Montant"] ? ["Montant"] : [])]) {
      const h = foundB.find((f) => f.label === key), ok = !!h && same(key, h.text, prof[key]);
      stat(B, key, ok); rowsB.push({ key, truth: prof[key], got: h ? h.text : "(missing)", ok });
    }
    /* PDF filled with test-A values */
    const keys = [], seen = {};
    tpl.fields.forEach((f) => { if (!seen[f.key]) { seen[f.key] = { key: f.key, kind: f.type === "check" ? "select" : "text", options: [] }; keys.push(seen[f.key]); } if (f.type === "check" && !seen[f.key].options.includes(f.match)) seen[f.key].options.push(f.match); });
    const values = OCRFill.autoMatch(keys, items);
    const out = await OCRFill.fillPdf(PDFLib, pdfBytes, tpl.fields, values);
    fs.writeFileSync(path.join(OUT, `profile-${n}.pdf`), out);
    const got = await readPdf(out), txt = got.text.join(" | "), problems = [];
    keys.forEach((k) => { if (k.key !== "Date") stat(finalStat, k.key, same(k.key, values[k.key] || "", prof[k.key] || "")); });
    for (const k of keys.filter((k) => k.kind === "text" && k.key !== "Autre (préciser)")) {
      const v = values[k.key]; if (!v) { problems.push(`${k.key}: no value collected`); continue; }
      if (k.key === "Date") { const d = OCRFill.parseDate(v); [d.day, d.month, d.year].forEach((x) => { if (!got.text.includes(x)) problems.push(`Date part ${x} missing`); }); continue; }
      if (tpl.fields.find((f) => f.key === k.key).type === "cells") { const dg = digits(v); for (let i = 0; i < 5; i++) if (!got.text.includes(dg.slice(i * 2, i * 2 + 2))) problems.push(`${k.key}: cell missing`); }
      else if (!txt.includes(v)) problems.push(`${k.key}: "${v}" not found in PDF`);
    }
    const expX = 2 * (["Civilité", "Pièce", "Offre"].filter((k) => values[k]).length + (values["Montant"] ? 1 : 0));
    if (got.paths - blank.paths !== expX) problems.push(`checkbox marks: expected ${expX / 2}, found ${(got.paths - blank.paths) / 2}`);
    results.push({ n, profile: prof, rowsA, rowsB, problems, pdf: `profile-${n}.pdf` });
    console.log(`#${String(n).padStart(2)} ${prof["Nom"]} ${prof["Prénom"]}  A ${rowsA.filter((r) => r.ok).length}/${rowsA.length}  B ${rowsB.filter((r) => r.ok).length}/${rowsB.length}  PDF ${problems.length ? "FAIL: " + problems.join("; ") : "OK"}`);
  }
  await worker.terminate();

  const tot = (o) => Object.values(o).reduce((a, s) => [a[0] + s.ok, a[1] + s.n], [0, 0]);
  const [aOk, aN] = tot(A), [bOk, bN] = tot(B), [fOk, fN] = tot(finalStat), pdfFail = results.filter((r) => r.problems.length).length;
  const pct = (o) => (100 * o[0] / o[1]).toFixed(1) + "%";
  const esc = (s) => String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  const table = (o) => `<table><tr><th>Category</th><th>Correct</th></tr>${Object.entries(o).map(([k, s]) => `<tr class="${s.ok < s.n ? "bad" : ""}"><td>${esc(k)}</td><td>${s.ok}/${s.n} (${(100 * s.ok / s.n).toFixed(0)}%)</td></tr>`).join("")}</table>`;
  const html = `<!doctype html><meta charset="utf-8"><title>Test report</title><style>body{font:14px system-ui;margin:24px;max-width:1000px}table{border-collapse:collapse;width:100%;margin:10px 0}td,th{border:1px solid #ddd;padding:5px 8px;text-align:left;vertical-align:top}.bad{background:#fee2e2}.good{color:#15803d}</style>
<h1>Test agent report</h1><ul><li><b>A – value by value, auto-categorised:</b> ${pct([aOk, aN])} (${aOk}/${aN})</li><li><b>B – whole card in one screenshot:</b> ${pct([bOk, bN])} (${bOk}/${bN})</li><li><b>Final form values correct:</b> ${pct([fOk, fN])}</li><li><b>PDF filled &amp; verified:</b> ${results.length - pdfFail}/${results.length}</li><li>Uncertain (⚠) guesses: ${uncertainTotal}, of which wrong: ${uncertainWrong}</li></ul>
<h2>A – by category</h2>${table(A)}<h2>B – by category</h2>${table(B)}<h2>Final form values</h2>${table(finalStat)}
<h2>Profiles</h2>${results.map((r) => `<h3>#${r.n} ${esc(r.profile["Nom"])} ${esc(r.profile["Prénom"])} — ${r.problems.length ? '<span class="bad">' + r.problems.map(esc).join("; ") + "</span>" : '<span class="good">✓ PDF OK</span>'}</h3>
<table><tr><th>Field (A)</th><th>Screenshot text</th><th>OCR</th><th>Classified as</th></tr>${r.rowsA.map((x) => `<tr class="${x.ok ? "" : "bad"}"><td>${esc(x.key)}</td><td>${esc(x.truth)}</td><td>${esc(x.ocr)}</td><td>${esc(x.got)}</td></tr>`).join("")}</table>`).join("")}`;
  fs.writeFileSync(path.join(OUT, "report.html"), html);
  fs.writeFileSync(path.join(OUT, "results.json"), JSON.stringify({ A, B, finalStat, uncertainTotal, uncertainWrong, results }, null, 1));
  console.log(`\nA (value by value) : ${aOk}/${aN} ${pct([aOk, aN])}\nB (whole card)     : ${bOk}/${bN} ${pct([bOk, bN])}\nFinal form values  : ${fOk}/${fN} ${pct([fOk, fN])}\nPDF OK             : ${results.length - pdfFail}/${results.length}\nUncertain guesses  : ${uncertainTotal} (wrong: ${uncertainWrong})\nReport: ${path.join(OUT, "report.html")}`);
  process.exit(pdfFail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
