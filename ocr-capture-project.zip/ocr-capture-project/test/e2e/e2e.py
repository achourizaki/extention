# End-to-end test: python3 e2e.py <extension folder> <manifest version 2|3>
# Loads the extension in Chromium with ALL external network blocked, then: select a card with the mouse,
# select a single value, open the forms page, generate the PDF, open the field editor.
import subprocess, time, json, sys, os, urllib.request
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__)); FIX=os.path.abspath(os.path.join(HERE,'..','fixtures')); SRC=os.path.abspath(os.path.join(HERE,'..','..','src'))
EXT=sys.argv[1]; MV=int(sys.argv[2]); TAG=sys.argv[3]
srv=subprocess.Popen(['python3','-m','http.server','8765','-d',FIX],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
blocked=[]
def handler(route):
    u=route.request.url
    if u.startswith(('http://localhost:8765','data:','blob:','chrome-extension:')): route.continue_()
    else: blocked.append(u); route.abort()
CHROME=os.environ.get('CHROME_BIN','/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
ok=True
def check(name,cond,detail=''):
    global ok; ok=ok and cond; print(('PASS' if cond else 'FAIL'),name,detail)
with sync_playwright() as p:
    if MV==3:
        ctx=p.chromium.launch_persistent_context('/tmp/prof_3_'+str(int(time.time())),executable_path=CHROME,headless=False,
            args=['--headless=new','--no-sandbox',f'--disable-extensions-except={EXT}',f'--load-extension={EXT}'],viewport={'width':1280,'height':900})
        sw=ctx.service_workers[0] if ctx.service_workers else ctx.wait_for_event('serviceworker',timeout=15000)
        ext=sw.url.split('/')[2]
    else:
        proc=subprocess.Popen([CHROME,'--headless=new','--no-sandbox','--user-data-dir=/tmp/prof_2_'+str(int(time.time())),f'--disable-extensions-except={EXT}',f'--load-extension={EXT}',
            '--disable-features=ExtensionManifestV2Unsupported,ExtensionManifestV2Disabled,ExtensionManifestV2Deprecation','--remote-debugging-port=9334','about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        time.sleep(5)
        ext=[t['url'].split('/')[2] for t in json.load(urllib.request.urlopen('http://localhost:9334/json/list')) if t['type']=='background_page'][0]
        ctx=p.chromium.connect_over_cdp('http://localhost:9334').contexts[0]
    print('manifest version',MV,'extension',ext)
    ctx.route('**/*',handler)
    ctl=None
    if MV==2:
        ctl=ctx.new_page(); ctl.goto(f'chrome-extension://{ext}/popup.html')   # acts like the popup
    def items():
        if MV==3: return sw.evaluate("browser.storage.local.get('items').then(r=>r.items||[])")
        return ctl.evaluate("browser.storage.local.get('items').then(r=>r.items||[])")
    def setitems(v):
        if MV==3: sw.evaluate("(v)=>browser.storage.local.set({items:v})",v)
        else: ctl.evaluate("(v)=>browser.storage.local.set({items:v})",v)
    def start(mode):
        if MV==3: sw.evaluate(f"start('{mode}')")
        else: ctl.evaluate(f"browser.runtime.sendMessage({{type:'start',mode:'{mode}'}})")
    page=ctx.new_page(); page.set_viewport_size({'width':1280,'height':900}); page.goto('http://localhost:8765/profils-test-offline.html'); page.wait_for_selector('article'); page.bring_to_front()
    art=page.locator('article').first
    exp={dt.inner_text():dd.inner_text() for dt,dd in zip(art.locator('dt').all(),art.locator('dd').all())}
    def drag(b,pad=1):
        page.mouse.move(b['x']+pad,b['y']+pad); page.mouse.down(); page.mouse.move(b['x']+b['width']-pad,b['y']+b['height']-pad,steps=8); page.mouse.up()
    def wait_items(t=90):
        t0=time.time()
        while time.time()-t0<t:
            got=items()
            if got: return got
            time.sleep(1)
        return []
    # 1. whole card
    setitems([]); page.bring_to_front(); start('select'); time.sleep(1); drag(art.bounding_box())
    got=wait_items(); lab={i['label']:i['text'] for i in got}
    want={'Nom':exp['Nom'],'Prénom':exp['Prénom'],'Date de naissance':exp['Date de naissance'],'Lieu de naissance':exp['Lieu de naissance'],'Téléphone':exp['Téléphone'].replace(' ',''),
          'N° de contact':exp['N° de contact'].replace(' ',''),'Pièce':exp['Pièce'],'N° pièce':exp['N° de la pièce'],'Date de délivrance':exp['Délivrée le'],'Délivrée à':exp['Délivrée à'],'Offre':exp['Offre']}
    bad={k:(lab.get(k),v) for k,v in want.items() if lab.get(k)!=v}
    check('1 whole card selected with the mouse -> all fields classified',not bad and 'Civilité' in lab,f'{len(lab)} fields {bad or ""}')
    # 2. single value
    setitems([]); page.bring_to_front(); start('select'); time.sleep(1)
    bb=art.locator('dd').nth(4).bounding_box(); page.mouse.move(bb['x']-2,bb['y']-2); page.mouse.down(); page.mouse.move(bb['x']+bb['width']+4,bb['y']+bb['height']+2,steps=6); page.mouse.up()
    one={i['label']:i['text'] for i in wait_items(60)}
    check('2 single phone selected -> classified as Téléphone',one.get('Téléphone')==want['Téléphone'],str(one))
    # 3. whole visible page
    setitems([]); page.bring_to_front(); start('page'); got3=wait_items(120)
    check('3 "Analyser la page" reads the visible page',len(got3)>=3,f'{len(got3)} fields: '+', '.join(i['label'] for i in got3)[:90])
    # 4. forms page + PDF
    setitems(got)
    fp=ctx.new_page(); fp.goto(f'chrome-extension://{ext}/forms.html'); fp.wait_for_selector('.tpl'); fp.click('.tpl'); fp.wait_for_selector('#grid input'); time.sleep(1)
    fp.click('#gen'); fp.wait_for_selector('#dl:not([disabled])',timeout=30000)
    with fp.expect_download() as d: fp.click('#dl')
    out=f'/tmp/e2e_out_{TAG}.pdf'; d.value.save_as(out)
    txt=subprocess.run(['pdftotext','-layout',out,'-'],capture_output=True,text=True).stdout
    check('4 PDF generated and contains the values',all(x in txt for x in [exp['Nom'],exp['Prénom'],exp['Date de naissance'],exp['Lieu de naissance'],exp['N° de la pièce']]),f'{os.path.getsize(out)} bytes')
    # 5. editor renders the PDF (pdf.js)
    fp.click('#tabEdit'); fp.wait_for_selector('.box',timeout=20000)
    check('5 field editor shows the form with its 40 boxes',fp.locator('.box').count()==40,str(fp.locator('.box').count()))
    ext_calls=[u for u in blocked if 'localhost' not in u]
    print('external requests attempted by the extension:',[u for u in ext_calls if 'googleapis' not in u] or 'none')
    try: ctx.close()
    except Exception: pass
    if MV!=3: proc.terminate()
srv.terminate()
print('RESULT','ALL PASS' if ok else 'SOME FAILED'); sys.exit(0 if ok else 1)
