# Upload NEW forms (never seen before) and check that the collected values are placed automatically.
import subprocess, time, json, sys, os
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__)); FIX=os.path.abspath(os.path.join(HERE,'..','fixtures')); SRC=os.path.abspath(os.path.join(HERE,'..','..','src'))
EXT=sys.argv[1]; MV=int(sys.argv[2])
CHROME=os.environ.get('CHROME_BIN','/opt/pw-browsers/chromium-1194/chrome-linux/chrome')
ITEMS=[('Civilité','Madame'),('Nom','Bouzid'),('Prénom','Sarah'),('Date de naissance','12/03/1967'),('Lieu de naissance','Annaba'),('Téléphone','0669810509'),('N° de contact','0728110350'),
('Pièce','CIN'),('N° pièce','455157384'),('Date de délivrance','22/04/2017'),('Délivrée à','Blida'),('Offre','SAMA LIBRE'),('Montant','2000'),('Email','sarah@mail.dz'),('Adresse','12 rue des Roses, Alger'),('Profession','Ingénieur')]
items=[{'id':i+1,'label':l,'text':t} for i,(l,t) in enumerate(ITEMS)]
FORMS=[('mobilis (raw PDF, no preset)',SRC+'/preset/mobilis.pdf',['Bouzid','Sarah','12/03/1967','Annaba','455157384','22/04/2017','Blida','06','69','81','05','09']),
       ('inscription (other PDF layout)',FIX+'/inscription.pdf',['Bouzid','Sarah','12/03/1967','Annaba','12 rue des Roses','sarah@mail.dz','455157384','06','69']),
       ('fiche (Word)',FIX+'/fiche.docx',['Bouzid','Sarah','12/03/1967','Annaba','12 rue des Roses','sarah@mail.dz','455157384','Ingénieur','06|69|81|05|09']),
       ('scan (image-only PDF)',FIX+'/mobilis_scan.pdf',['Sarah','12/03/1967','455157384','22/04/2017'])]
ok=True
with sync_playwright() as p:
    if MV==3:
        ctx=p.chromium.launch_persistent_context('/tmp/pf_%d'%time.time(),executable_path=CHROME,headless=False,args=['--headless=new','--no-sandbox',f'--disable-extensions-except={EXT}',f'--load-extension={EXT}'])
        sw=ctx.service_workers[0] if ctx.service_workers else ctx.wait_for_event('serviceworker',timeout=15000); ext=sw.url.split('/')[2]
    else:
        import urllib.request
        proc=subprocess.Popen([CHROME,'--headless=new','--no-sandbox','--user-data-dir=/tmp/pf2_%d'%time.time(),f'--disable-extensions-except={EXT}',f'--load-extension={EXT}','--disable-features=ExtensionManifestV2Unsupported,ExtensionManifestV2Disabled,ExtensionManifestV2Deprecation','--remote-debugging-port=9335','about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        time.sleep(5); ext=[t['url'].split('/')[2] for t in json.load(urllib.request.urlopen('http://localhost:9335/json/list')) if t['type']=='background_page'][0]
        ctx=p.chromium.connect_over_cdp('http://localhost:9335').contexts[0]
    fp=ctx.new_page(); fp.goto(f'chrome-extension://{ext}/forms.html'); fp.wait_for_selector('.tpl')
    fp.evaluate("(v)=>browser.storage.local.set({items:v})",items)
    for name,path,expect in FORMS:
        print('====',name)
        t0=time.time(); fp.set_input_files('#up',path)
        fp.wait_for_function("(n)=>document.getElementById('tname').textContent===n && /^(✓|Aucun)/.test(document.getElementById('autoMsg').textContent)",arg=os.path.splitext(os.path.basename(path))[0],timeout=180000)
        msg=fp.inner_text('#autoMsg'); print('   template:',fp.inner_text('#tname'),'|',msg[:150],f'({time.time()-t0:.1f}s)')
        time.sleep(1)
        cells=fp.eval_on_selector_all('#grid > *',"els=>els.map(e=>e.tagName==='DIV'?'§'+e.textContent:(e.tagName==='SELECT'&&e.options.length>3&&e.options[0].text==='choose…'?'':(e.value||'')))")
        vals={}; k=None
        for c_ in cells[3:]:
            if c_.startswith('§'): k=c_[1:]; vals[k]=''
            elif k and c_ and not vals[k]: vals[k]=c_
        print('   filled:',{a:b for a,b in vals.items() if b})
        print('   empty :',[a for a,b in vals.items() if not b])
        fp.click('#gen'); fp.wait_for_selector('#dl:not([disabled])',timeout=60000)
        with fp.expect_download() as d: fp.click('#dl')
        out='/tmp/formtest_'+name.split()[0]+('.docx' if 'Word' in name else '.pdf'); d.value.save_as(out)
        if out.endswith('.pdf'): txt=subprocess.run(['pdftotext','-layout',out,'-'],capture_output=True,text=True).stdout
        else:
            import docx; dd=docx.Document(out); txt='\n'.join(p_.text for p_ in dd.paragraphs)+'\n'+'\n'.join(c_.text for t_ in dd.tables for r in t_.rows for c_ in r.cells)
        miss=[e for e in expect if e not in txt]
        good=not miss; ok=ok and good
        print('  ','PASS' if good else 'FAIL','missing in output:',miss)
    try: ctx.close()
    except Exception: pass
    if MV!=3: proc.terminate()
print('RESULT','ALL PASS' if ok else 'SOME FAILED'); sys.exit(0 if ok else 1)
