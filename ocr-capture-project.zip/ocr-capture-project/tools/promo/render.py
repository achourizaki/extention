import sys, subprocess, os, shutil
from playwright.sync_api import sync_playwright
lang=sys.argv[1]; FPS=24; DUR=42.0; N=int(FPS*DUR)
d=f'/tmp/frames_{lang}'; shutil.rmtree(d,ignore_errors=True); os.makedirs(d)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':720}); pg.goto(f'file:///home/claude/promo/promo.html?lang={lang}')
    for i in range(N):
        pg.evaluate("t=>setT(t)",i/FPS); pg.screenshot(path=f'{d}/{i:05d}.jpg',type='jpeg',quality=90)
    b.close()
subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate',str(FPS),'-i',f'{d}/%05d.jpg','-i','/home/claude/promo/audio.wav','-c:v','libx264','-pix_fmt','yuv420p','-crf','20','-c:a','aac','-b:a','160k','-shortest','-movflags','+faststart',f'/mnt/user-data/outputs/ocr-capture-promo-{lang}.mp4'],check=True)
print('ok',lang)
